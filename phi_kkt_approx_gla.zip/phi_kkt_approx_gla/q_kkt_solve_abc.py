"""Fused Phi-KKT (abc) + Simple-GLA autograd.

One ``torch.autograd.Function`` owns both the polynomial apply

    x = a q + b (q @ H)/F + c (q @ H^2)/F^2

and the subsequent GLA recurrence. Matches GDN's checkpoint style:

- ``k`` is saved once (not once per op).
- Mixed query ``q_gla = (1-α) q + α x`` is reconstructed in backward.
- GLA chunk state ``h_kv`` is recomputed, not stored.
- Chunk-level ``h_kk`` is dropped after forward and rebuilt in backward.
- Triton kernels are reused from ``phi_kkt_approx.q_kkt_solve_abc_fast_2``.
"""
from typing import Optional, Sequence, Tuple, Union

import torch
from torch import Tensor

from fla.ops.simple_gla.chunk import chunk_simple_gla_bwd, chunk_simple_gla_fwd
from fla.ops.utils import chunk_local_cumsum

from ..phi_kkt_approx.q_kkt_solve_abc_fast_2 import (
    _bwd_dH_to_dk_dgk,
    _bwd_prep_du_dv_alpha,
    _normalize_abc,
    q_kkt_solve_approx_backward_triton,
    q_kkt_solve_approx_forward_triton,
)


def _poly_x_out(
    q: Tensor,
    o1: Tensor,
    o2: Tensor,
    abc_heads: Tensor,
) -> Tensor:
    """Reconstruct x = a q + b o1 + c o2 in fp32, store as ``q.dtype``."""
    a = abc_heads[:, 0].view(1, 1, -1, 1)
    b = abc_heads[:, 1].view(1, 1, -1, 1)
    c = abc_heads[:, 2].view(1, 1, -1, 1)
    return (a * q.float() + b * o1.float() + c * o2.float()).to(q.dtype)


def _mix_q(q: Tensor, x_out: Tensor, alpha: Tensor) -> Tensor:
    return q + alpha[..., None] * (x_out - q)


def _cumsum_gates(
    g: Optional[Tensor],
    gk: Optional[Tensor],
    chunk_size: int,
) -> Tuple[Optional[Tensor], Optional[Tensor]]:
    """Cumsum GLA gate ``g`` and KKT gate ``gk``. Reuse storage when they alias."""
    gkk = chunk_local_cumsum(gk, chunk_size=chunk_size) if gk is not None else None
    if g is None:
        g_cum = None
    elif gk is g:
        g_cum = gkk
    else:
        g_cum = chunk_local_cumsum(g, chunk_size=chunk_size)
    return g_cum, gkk


def _pack_abc_grad(
    d_abc_h: Tensor,
    abc_shape: Tuple[int, ...],
    abc_dtype: torch.dtype,
    abc_device: torch.device,
) -> Tensor:
    if abc_shape == (3,) or (len(abc_shape) == 1 and abc_shape[0] == 3):
        d_abc = d_abc_h.sum(dim=0)
    else:
        d_abc = d_abc_h
    return d_abc.to(dtype=abc_dtype, device=abc_device).reshape(abc_shape)


class q_kkt_solve_approx(torch.autograd.Function):
    """Fused abc polynomial apply + alpha mix + chunk Simple-GLA."""

    @staticmethod
    def forward(
        ctx,
        k: Tensor,
        q: Tensor,
        v: Tensor,
        alpha: Tensor,
        g: Optional[Tensor],
        gk: Optional[Tensor],
        chunk_size: int,
        learnable_abc: Union[Tensor, Sequence[float]],
        gla_scale: float,
        h0_kk=None,
        h0_kv=None,
        output_final_state: bool = False,
    ) -> Tuple[Tensor, Optional[Tensor], Optional[Tensor]]:
        B, T, H, _D = q.shape
        assert torch.is_tensor(learnable_abc), "learnable_abc must be a tensor"
        assert learnable_abc.dtype == torch.float32, (
            f"learnable_abc.dtype must be float32, got {learnable_abc.dtype}"
        )
        ctx.abc_dtype = learnable_abc.dtype
        ctx.abc_device = learnable_abc.device
        ctx.abc_shape = tuple(learnable_abc.shape)

        abc_heads = _normalize_abc(learnable_abc, H, q.device, torch.float32)
        g_cum, gkk = _cumsum_gates(g, gk, chunk_size)

        fro = torch.empty((B, T, H), dtype=torch.float32, device=q.device)
        x_out, o1, o2, fro, h_kk, h_kk_final = q_kkt_solve_approx_forward_triton(
            k,
            q,
            gkk,
            fro,
            learnable_abc=abc_heads,
            chunk_size=chunk_size,
            load_fro=0,
            output_final_state=output_final_state,
            h0=h0_kk,
        )
        del h_kk
        q_gla = _mix_q(q, x_out, alpha)
        o, kv_final = chunk_simple_gla_fwd(
            q=q_gla,
            k=k,
            v=v,
            g=g_cum,
            g_gamma=None,
            scale=gla_scale,
            initial_state=h0_kv,
            output_final_state=output_final_state,
            cu_seqlens=None,
            chunk_size=chunk_size,
        )

        to_save = [k, q, v, alpha, o1, o2, fro, abc_heads]
        if g_cum is not None:
            to_save.append(g_cum)
        if gk is not None:
            to_save.append(gk)
        if gkk is not None:
            to_save.append(gkk)
        if h0_kk is not None:
            to_save.append(h0_kk)
        if h0_kv is not None:
            to_save.append(h0_kv)
        ctx.save_for_backward(*to_save)
        ctx.chunk_size = chunk_size
        ctx.gla_scale = gla_scale
        ctx.has_g_cum = g_cum is not None
        ctx.has_gk = gk is not None
        ctx.has_gkk = gkk is not None
        ctx.has_h0_kk = h0_kk is not None
        ctx.has_h0_kv = h0_kv is not None
        return o.to(q.dtype), h_kk_final, kv_final

    @staticmethod
    def backward(
        ctx,
        do: Tensor,
        d_kk_final: Optional[Tensor] = None,
        d_kv_final: Optional[Tensor] = None,
    ):
        saved = list(ctx.saved_tensors)
        k, q, v, alpha, o1, o2, fro, abc_heads = saved[:8]
        idx = 8
        g_cum = saved[idx] if ctx.has_g_cum else None
        idx += int(ctx.has_g_cum)
        gk = saved[idx] if ctx.has_gk else None
        idx += int(ctx.has_gk)
        gkk = saved[idx] if ctx.has_gkk else None
        idx += int(ctx.has_gkk)
        h0_kk = saved[idx] if ctx.has_h0_kk else None
        idx += int(ctx.has_h0_kk)
        h0_kv = saved[idx] if ctx.has_h0_kv else None
        chunk_size = ctx.chunk_size
        gla_scale = ctx.gla_scale

        x_out = _poly_x_out(q, o1, o2, abc_heads)
        q_gla = _mix_q(q, x_out, alpha)

        dq_gla, dk_gla, dv, dg_cum, dh0_kv = chunk_simple_gla_bwd(
            q=q_gla,
            k=k,
            v=v,
            g=g_cum,
            g_gamma=None,
            initial_state=h0_kv,
            do=do,
            dht=d_kv_final,
            scale=gla_scale,
            cu_seqlens=None,
            chunk_size=chunk_size,
        )
        dg = None
        if g_cum is not None:
            dg = chunk_local_cumsum(
                dg_cum, chunk_size=chunk_size, reverse=True, cu_seqlens=None
            ).to(dtype=g_cum.dtype)

        dx_out = dq_gla * alpha[..., None]
        dq_mix = dq_gla * (1.0 - alpha[..., None])
        d_alpha = (dq_gla * (x_out - q)).sum(dim=-1)

        dq_kkt, dx1, fro, h_kk, _ = q_kkt_solve_approx_backward_triton(
            k,
            dx_out,
            gkk,
            fro,
            learnable_abc=abc_heads,
            chunk_size=chunk_size,
            load_fro=1,
            output_final_state=False,
            h0=h0_kk,
            h_kk=None,
        )
        need_dabc = bool(ctx.needs_input_grad[7])
        du, dv_poly, alpha_h, d_abc_h = _bwd_prep_du_dv_alpha(
            q, o1, o2, dx_out, dx1, fro, abc_heads, chunk_size, need_dabc
        )
        dk_kkt, dgk, dh0_kk = _bwd_dH_to_dk_dgk(
            k,
            q,
            o1,
            du,
            dv_poly,
            alpha_h,
            gk,
            gkk,
            d_kk_final,
            h_kk,
            h0_kk,
            chunk_size,
        )
        d_abc = (
            _pack_abc_grad(d_abc_h, ctx.abc_shape, ctx.abc_dtype, ctx.abc_device)
            if need_dabc
            else None
        )
        dq = dq_mix + dq_kkt
        dk = dk_gla + dk_kkt
        return (
            dk,
            dq,
            dv,
            d_alpha,
            dg,
            dgk,
            None,
            d_abc,
            None,
            dh0_kk,
            dh0_kv,
            None,
        )
