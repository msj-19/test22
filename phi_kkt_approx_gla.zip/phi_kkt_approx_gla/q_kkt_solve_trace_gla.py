"""Trace-phi + vector-gate GLA, composed so both train in one call.

Phi uses ``q_kkt_solve_trace_triton_seg`` (trace norm, per-dimension half-gate,
sub-block relative exponents). The value recurrence is ``chunk_gla``:

    Hkv_t = Hkv_{t-1} * exp(g_t) + k_t v_t^T     (decay on the key axis)
    o_t   = scale * q_mix_t @ Hkv_t
    q_mix = q + alpha * (x - q)

``g`` / ``gk`` may be ``[B, T, H]`` (broadcast over D) or ``[B, T, H, D]``.
Coefficient count is the last dim of ``learnable_abc``: 3 or 4.
This path does not call ``simple_gla``.
"""
from typing import Optional, Sequence, Tuple, Union

import torch
from torch import Tensor

from fla.ops.gla import chunk_gla

from ..phi_kkt_approx.q_kkt_solve_trace_triton_seg import q_kkt_solve_trace_triton_seg


def _as_head_gate(gate: Optional[Tensor], like: Tensor) -> Optional[Tensor]:
    """Broadcast ``[B, T, H]`` or ``[B, T, H, D]`` onto ``like``'s last dim."""
    if gate is None:
        return None
    if gate.shape == like.shape:
        return gate
    if gate.ndim == like.ndim - 1 and gate.shape == like.shape[:-1]:
        return gate.unsqueeze(-1).expand_as(like)
    raise ValueError(
        f"gate must be {tuple(like.shape)} or {tuple(like.shape[:-1])}, got {tuple(gate.shape)}"
    )


def phi_kkt_solve_trace_gla(
    q: Tensor,
    k: Tensor,
    v: Tensor,
    alpha: Tensor,
    g: Optional[Tensor],
    gk: Optional[Tensor],
    gla_scale: float,
    learnable_abc: Union[Tensor, Sequence[float]],
    chunk_size: int = 64,
    h0_kk: Optional[Tensor] = None,
    h0_kv: Optional[Tensor] = None,
    output_final_state: bool = True,
) -> Tuple[Tensor, Optional[Tensor], Optional[Tensor]]:
    """x = phi_trace(q, k, gk), then vector-gate GLA on the alpha-mixed query.

    Returns ``o [B, T, H, D]``, ``H_kk`` (or None), ``H_kv`` (or None).
    """
    if q.ndim != 4:
        raise ValueError(f"q must be [B, T, H, D], got {tuple(q.shape)}")
    gk_vec = _as_head_gate(gk, k)
    g_vec = _as_head_gate(g, k)
    if g_vec is None:
        g_vec = torch.zeros_like(k, dtype=torch.float32)
    x, h_kk = q_kkt_solve_trace_triton_seg.apply(
        k, q, gk_vec, chunk_size, learnable_abc, h0_kk,
    )
    q_mix = q + alpha[..., None] * (x - q)
    h0 = None if h0_kv is None else h0_kv.float().contiguous()
    o, h_kv = chunk_gla(
        q_mix,
        k,
        v,
        g_vec,
        scale=float(gla_scale),
        initial_state=h0,
        output_final_state=output_final_state,
    )
    if not output_final_state:
        h_kk = None
    return o, h_kk, h_kv
