"""Accuracy and speed of trace-phi + vector-gate GLA.

Run:
    CUDA_VISIBLE_DEVICES=0 \\
    TRACE_KKT_DOT_PRECISION=tf32x3 \\
    /9950backfile/meishj/.conda/envs/msj_triton36/bin/python \\
    flash-linear-attention/legacy/training/fla4/ops/phi_kkt_approx_gla/test_trace_gla.py
"""
import math
import os
import sys
import time

os.environ.setdefault("TRACE_KKT_DOT_PRECISION", "tf32x3")
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..")))

import torch
import torch.nn.functional as F

from fla4.ops.phi_kkt_approx.q_kkt_solve_trace import trace_kkt_reference
from fla4.ops.phi_kkt_approx_gla.decoding_trace import (
    phi_kkt_decoding_trace,
    phi_kkt_decoding_trace_ref,
)
from fla4.ops.phi_kkt_approx_gla.phi_kkt_solve_trace import (
    phi_kkt_decoding_one_step,
    phi_kkt_solve_gla,
)


def _rel(a, b):
    return ((a.float() - b.float()).norm() / b.float().norm().clamp(min=1e-8)).item()


def _max(a, b):
    return (a.float() - b.float()).abs().max().item()


def _report(name, a, b, limit):
    """``limit`` is a relative L2 tolerance. Absolute max is printed only."""
    mx, rel = _max(a, b), _rel(a, b)
    ok = math.isfinite(mx) and math.isfinite(rel) and rel <= limit
    print(f"  {name:8s} max {mx:.3e}  rel {rel:.3e}  [{'OK' if ok else 'FAIL'}]")
    return ok


def train_ref(q, k, v, alpha, g, gk, coeff, scale, h0_kk, h0_kv):
    x, h_kk = trace_kkt_reference(q, k, gk, coeff, h0_kk)
    q_mix = q + alpha[..., None] * (x - q)
    B, T, H, D = q.shape
    dt = torch.float32
    h = h0_kv.to(dt) if h0_kv is not None else q.new_zeros(B, H, D, D, dtype=dt)
    outs = []
    qm = q_mix.float()
    for t in range(T):
        h = h * torch.exp(g[:, t].to(dt))[..., None]
        kt = k[:, t].to(dt)
        vt = v[:, t].to(dt)
        h = h + kt[..., :, None] * vt[..., None, :]
        outs.append(scale * (qm[:, t].unsqueeze(-2) @ h).squeeze(-2))
    return torch.stack(outs, dim=1).to(q.dtype), h_kk, h


def check_train(B, T, H, D, N, C, seed, limit=2e-3):
    torch.manual_seed(seed)
    q = torch.randn(B, T, H, D, device="cuda", requires_grad=True)
    k = (torch.randn(B, T, H, D, device="cuda") / D ** 0.5).requires_grad_()
    v = torch.randn(B, T, H, D, device="cuda", requires_grad=True)
    alpha = torch.sigmoid(torch.randn(B, T, H, device="cuda")).requires_grad_()
    gk = (F.logsigmoid(torch.randn(B, T, H, D, device="cuda")) / 4).requires_grad_()
    g = (F.logsigmoid(torch.randn(B, T, H, D, device="cuda")) / 4).requires_grad_()
    coeff = torch.tensor([1.0, -0.5, 0.375, -0.3125][:N], device="cuda", requires_grad=True)
    a = torch.randn(B, H, D, D, device="cuda") / D
    h0_kk = (a @ a.transpose(-1, -2)).requires_grad_()
    h0_kv = torch.randn(B, H, D, D, device="cuda").div(D).requires_grad_()
    scale = D ** -0.5
    print(f"train B{B} T{T} H{H} D{D} N{N} C{C}")
    o1, s1, u1 = phi_kkt_solve_gla(
        q, k, v, alpha, g, gk, scale, coeff, C, h0_kk, h0_kv, True,
    )
    o2, s2, u2 = train_ref(q, k, v, alpha, g, gk, coeff, scale, h0_kk, h0_kv)
    ok = _report("o", o1, o2, limit) and _report("Hkk", s1, s2, limit) and _report("Hkv", u1, u2, limit)
    names = ("q", "k", "v", "alpha", "g", "gk", "coeff", "h0_kk", "h0_kv")
    grads = (q, k, v, alpha, g, gk, coeff, h0_kk, h0_kv)
    do = torch.randn_like(o1)
    dsk = torch.randn_like(s1)
    dsv = torch.randn_like(u1)
    g1 = torch.autograd.grad((o1.float() * do).sum() + (s1.float() * dsk).sum() + (u1.float() * dsv).sum(), grads)
    g2 = torch.autograd.grad((o2.float() * do).sum() + (s2.float() * dsk).sum() + (u2.float() * dsv).sum(), grads)
    for name, a, b in zip(names, g1, g2):
        ok &= _report("d" + name, a, b, limit)
    return ok


def check_decode(B, T, H, D, N, seed, strong=False, limit=2e-3):
    torch.manual_seed(seed)
    q = torch.randn(B, T, H, D, device="cuda")
    k = torch.randn(B, T, H, D, device="cuda") / D ** 0.5
    v = torch.randn(B, T, H, D, device="cuda")
    alpha = torch.sigmoid(torch.randn(B, T, H, device="cuda"))
    if strong:
        gk = -torch.rand(B, T, H, D, device="cuda") * 40
        g = -torch.rand(B, T, H, D, device="cuda") * 40
    else:
        gk = F.logsigmoid(torch.randn(B, T, H, D, device="cuda")) / 4
        g = F.logsigmoid(torch.randn(B, T, H, D, device="cuda")) / 4
    coeff = torch.tensor([1.0, -0.5, 0.375, -0.3125][:N], device="cuda")
    hkk = torch.randn(B, H, D, D, device="cuda") / D
    hkk = hkk @ hkk.transpose(-1, -2)
    hkv = torch.randn(B, H, D, D, device="cuda") / D
    scale = D ** -0.5
    tag = "strong" if strong else "mild"
    print(f"decode {tag} B{B} T{T} H{H} D{D} N{N}")
    o1, s1, u1 = phi_kkt_decoding_one_step(q, k, v, alpha, g, gk, scale, coeff, hkk, hkv)
    o2, s2, u2 = phi_kkt_decoding_trace_ref(q, k, v, alpha, g, gk, scale, coeff, hkk, hkv)
    ok = torch.isfinite(o1).all().item() and torch.isfinite(s1).all().item() and torch.isfinite(u1).all().item()
    print(f"  finite  [{('OK' if ok else 'FAIL')}]")
    ok &= _report("o", o1, o2, limit)
    ok &= _report("Hkk", s1, s2, limit)
    ok &= _report("Hkv", u1, u2, limit)
    gs, gks = g[..., 0].contiguous(), gk[..., 0].contiguous()
    o3, s3, u3 = phi_kkt_decoding_trace(q, k, v, alpha, gs, gks, scale, coeff, hkk, hkv)
    o4, s4, u4 = phi_kkt_decoding_trace_ref(q, k, v, alpha, gs, gks, scale, coeff, hkk, hkv)
    same = _report("o_bcast", o3, o4, limit) and _report("Hkk_b", s3, s4, limit) and _report("Hkv_b", u3, u4, limit)
    return ok and same


def bench():
    B, T, H, D, C, N = 1, 1024, 4, 64, 64, 3
    torch.manual_seed(0)
    q = torch.randn(B, T, H, D, device="cuda", dtype=torch.bfloat16, requires_grad=True)
    k = (torch.randn(B, T, H, D, device="cuda", dtype=torch.bfloat16) / 8).requires_grad_()
    v = torch.randn(B, T, H, D, device="cuda", dtype=torch.bfloat16, requires_grad=True)
    alpha = torch.sigmoid(torch.randn(B, T, H, device="cuda")).requires_grad_()
    gk = (F.logsigmoid(torch.randn(B, T, H, D, device="cuda")) / 8).requires_grad_()
    g = (F.logsigmoid(torch.randn(B, T, H, D, device="cuda")) / 8).requires_grad_()
    coeff = torch.tensor([1.0, -0.5, 0.375], device="cuda", requires_grad=True)
    scale = D ** -0.5

    def step():
        o, _, _ = phi_kkt_solve_gla(q, k, v, alpha, g, gk, scale, coeff, C, None, None, False)
        o.sum().backward()
        for t in (q, k, v, alpha, g, gk, coeff):
            t.grad = None

    for _ in range(3):
        step()
    torch.cuda.synchronize()
    iters = 10
    t0 = time.perf_counter()
    for _ in range(iters):
        step()
    torch.cuda.synchronize()
    ms = (time.perf_counter() - t0) * 1000 / iters
    print(f"\ntrain e2e T={T} H={H} D={D} N={N}  {ms:.3f} ms")

    q1 = q[:, :1].detach()
    k1 = k[:, :1].detach()
    v1 = v[:, :1].detach()
    a1 = alpha[:, :1].detach()
    g1 = g[:, :1].detach()
    gk1 = gk[:, :1].detach()
    for _ in range(3):
        phi_kkt_decoding_one_step(q1, k1, v1, a1, g1, gk1, scale, coeff.detach())
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(50):
        phi_kkt_decoding_one_step(q1, k1, v1, a1, g1, gk1, scale, coeff.detach())
    torch.cuda.synchronize()
    print(f"decode T=1 H={H} D={D}  {(time.perf_counter() - t0) * 1000 / 50:.3f} ms")


def main():
    assert torch.cuda.is_available()
    ok = True
    ok &= check_train(1, 16, 1, 16, 3, 16, 0, limit=2e-3)
    ok &= check_train(1, 20, 2, 16, 4, 16, 1, limit=2e-3)
    ok &= check_decode(1, 3, 2, 16, 3, 2)
    ok &= check_decode(1, 2, 1, 32, 4, 3)
    ok &= check_decode(1, 2, 1, 16, 3, 4, strong=True, limit=5e-2)
    if not ok:
        raise SystemExit("trace gla does not match the reference")
    bench()
    print("\nall cases passed")


if __name__ == "__main__":
    main()
