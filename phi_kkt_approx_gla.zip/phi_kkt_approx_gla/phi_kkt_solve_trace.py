"""Public entry for trace-phi + vector-gate GLA.

Training: ``phi_kkt_solve_gla`` (segmented trace kernel, then ``chunk_gla``).
Decode: ``phi_kkt_decoding_one_step`` (one Triton launch, no ``simple_gla``).
"""
from typing import Optional, Sequence, Tuple, Union

from torch import Tensor

from .decoding_trace import phi_kkt_decoding_trace
from .q_kkt_solve_trace_gla import phi_kkt_solve_trace_gla


def phi_kkt_solve_gla(
    q: Tensor,
    k: Tensor,
    v: Tensor,
    alpha: Tensor,
    g: Optional[Tensor],
    gk: Optional[Tensor],
    gla_scale: float,
    learnable_abc: Union[Tensor, Sequence[float]],
    chunk_size: int = 64,
    h0_kk: Optional[Tensor] = None,
    h0_kv: Optional[Tensor] = None,
    output_final_state: bool = True,
) -> Tuple[Tensor, Optional[Tensor], Optional[Tensor]]:
    return phi_kkt_solve_trace_gla(
        q, k, v, alpha, g, gk, gla_scale, learnable_abc,
        chunk_size=chunk_size, h0_kk=h0_kk, h0_kv=h0_kv,
        output_final_state=output_final_state,
    )


def phi_kkt_decoding_one_step(
    q: Tensor,
    k: Tensor,
    v: Tensor,
    alpha: Tensor,
    g: Optional[Tensor],
    gk: Optional[Tensor],
    gla_scale: float,
    learnable_abc: Union[Tensor, Sequence[float]],
    prev_h_kk: Optional[Tensor] = None,
    prev_h_kv: Optional[Tensor] = None,
) -> Tuple[Tensor, Tensor, Tensor]:
    return phi_kkt_decoding_trace(
        q, k, v, alpha, g, gk, gla_scale, learnable_abc, prev_h_kk, prev_h_kv,
    )
