"""Triton chunk implementation of trace-normalized phi-KKT.

Same recurrence as ``q_kkt_solve_trace.py``:

    H_t = Diag(exp(gk_t / 2)) H_{t-1} Diag(exp(gk_t / 2)) + k_t k_t^T
    x_t = sum_m coeff[m] * q_t (H_t / tr H_t)^m

Kernels:

    chunk_fwd_h              states before each chunk (gk = gv = half-cumsum)
    trace_fwd_kernel         tr(H) and o_1 .. o_{N-1}, x
    trace_bwd_chunk_kernel   p_j = dx H^j / F^j, dq, alpha, dcoeff, intra-chunk dk / dgk, g_partial
    trace_bwd_scan_kernel    gin[c-1] = g_partial[c] + Diag(E_C) gin[c] Diag(E_C)
    trace_bwd_gin_kernel     S_in contribution from later chunks

Backward identities used by ``trace_bwd_chunk_kernel`` (X_m = o_{m-1} E,
Y_m = u_m E, u_m = do_m / F, B_j = tril((p_j E) k'^T)):

    X_m H_in + tril(X_m k'^T) k' = o_m F / E
    Y_m H_in + tril(Y_m k'^T) k' = w_m / E,     w_m = sum_j coeff[m+j] p_{j+1}

so the low-rank dgk terms (H_in part plus in-chunk corner sums) collapse to

    suffix( sum_m (o_{m-1} * w_m + do_m * o_m) - k' * Z ),
    Z = sum_m tril(Y_m k'^T)^T X_m + tril(X_m k'^T)^T Y_m,

and Z is the low-rank part of dk. tril(Y_m k'^T) is a combination of the B_j
already formed while applying H to dx:

    sum_m tril(Y_m k'^T)^T X_m = sum_j B_j^T Xt_j,
    Xt_j = (E / F) sum_{m=1}^{N-1-j} coeff[m+j] o_{m-1}.
"""
import os
from typing import Optional, Sequence, Tuple, Union

import torch
import triton
import triton.language as tl

from fla.ops.common.chunk_h import chunk_fwd_h
from fla.ops.utils import chunk_local_cumsum


EPS = 1e-12
# Matmul operand precision; gate math (exp, cumsums) is always fp32.
#   bf16    operands cast to bf16, fp32 accumulate (fastest; dk ~3e-3, dgk ~9e-3 rel. error)
#   tf32    fp32 operands on TF32 tensor cores (dk / dgk ~1.5e-3)
#   tf32x3  hand-written 3xTF32 (dk / dgk ~1e-4, bounded by chunk_fwd_h), ~2x slower than tf32
# The tf32 / tf32x3 values are bit masks over the ``_dot`` call sites (set bit = 3xTF32).
_PREC_MASKS = {"tf32": 0, "tf32x3": 0x7F, "bf16": 0x100}
DOT_PRECISION = _PREC_MASKS[os.environ.get("TRACE_KKT_DOT_PRECISION", "bf16")]


def _choose_block_d(D: int) -> int:
    if D % 64 == 0:
        return 64
    if D % 32 == 0:
        return 32
    if D % 16 == 0:
        return 16
    raise ValueError(f"head dim D={D} must be divisible by 16, 32, or 64")


def _choose_scan_block(D: int) -> int:
    return 8 if D >= 16 else D


def _normalize_coeff(coeff, H: int, device, dtype=torch.float32) -> torch.Tensor:
    if torch.is_tensor(coeff):
        t = coeff.detach().to(device=device, dtype=dtype)
    else:
        t = torch.tensor(list(coeff), device=device, dtype=dtype)
    if t.dim() == 1:
        t = t.reshape(1, -1).expand(H, -1).contiguous()
    elif t.shape[0] != H:
        raise ValueError(f"coeff must be [N] or [H, N] with H={H}, got {tuple(t.shape)}")
    else:
        t = t.contiguous()
    if t.shape[-1] not in (3, 4):
        raise ValueError(f"coeff last dim must be 3 or 4, got {t.shape[-1]}")
    return t


# ---------------------------------------------------------------------------
# Loads / stores. Layout [B, T, H, D], pointer already at one (b, h).
# ---------------------------------------------------------------------------
@triton.jit
def _load_vec(ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D: tl.constexpr):
    p = tl.make_block_ptr(
        ptr, (T, D), (H * D, 1),
        (chunk_id * chunk_size, d0), (chunk_size, BLOCK_D), (1, 0),
    )
    x = tl.load(p, boundary_check=(0, 1)).to(tl.float32)
    return tl.where(m_t[:, None], x, 0.0)


@triton.jit
def _store_vec(ptr, val, T, H, D, chunk_id, chunk_size, d0, BLOCK_D: tl.constexpr):
    p = tl.make_block_ptr(
        ptr, (T, D), (H * D, 1),
        (chunk_id * chunk_size, d0), (chunk_size, BLOCK_D), (1, 0),
    )
    tl.store(p, val.to(p.dtype.element_ty), boundary_check=(0, 1))


@triton.jit
def _load_mat(ptr, D, r0, c0, BLOCK_D: tl.constexpr):
    p = tl.make_block_ptr(ptr, (D, D), (D, 1), (r0, c0), (BLOCK_D, BLOCK_D), (1, 0))
    return tl.load(p, boundary_check=(0, 1)).to(tl.float32)


@triton.jit
def _store_mat(ptr, val, D, r0, c0, BLOCK_D: tl.constexpr):
    p = tl.make_block_ptr(ptr, (D, D), (D, 1), (r0, c0), (BLOCK_D, BLOCK_D), (1, 0))
    tl.store(p, val.to(p.dtype.element_ty), boundary_check=(0, 1))


@triton.jit
def _load_row(ptr, T, H, chunk_id, chunk_size, m_t, other):
    p = tl.make_block_ptr(ptr, (T,), (H,), (chunk_id * chunk_size,), (chunk_size,), (0,))
    return tl.where(m_t, tl.load(p, boundary_check=(0,)).to(tl.float32), other)


@triton.jit
def _store_row(ptr, val, T, H, chunk_id, chunk_size):
    p = tl.make_block_ptr(ptr, (T,), (H,), (chunk_id * chunk_size,), (chunk_size,), (0,))
    tl.store(p, val.to(p.dtype.element_ty), boundary_check=(0,))


@triton.jit
def _masks(chunk_id, chunk_size, T):
    o_t = chunk_id * chunk_size + tl.arange(0, chunk_size)
    m_t = o_t < T
    tril = (o_t[:, None] >= o_t[None, :]) & (m_t[:, None] & m_t[None, :])
    return m_t, tril


@triton.jit
def _suffix(x):
    """Inclusive suffix sum over the chunk axis. x: [C, BD].

    Not total - cumsum + x: the tail entries are tiny next to the head (alpha E^2
    decays) and that difference leaves O(eps * head) behind, later scaled by E^{-2}.
    """
    return tl.cumsum(x, axis=0, reverse=True)


@triton.jit
def _excl(x):
    """Exclusive prefix sum over the chunk axis."""
    return tl.cumsum(x, axis=0) - x


@triton.jit
def _diag_of(tile, BLOCK_D: tl.constexpr):
    ar = tl.arange(0, BLOCK_D)
    return tl.sum(tl.where(ar[:, None] == ar[None, :], tile, 0.0), axis=1)


@triton.jit
def _split_tf32(x):
    hi = (x.to(tl.uint32, bitcast=True) & 0xFFFFE000).to(tl.float32, bitcast=True)
    return hi, x - hi


@triton.jit
def _dot(a, b, PREC: tl.constexpr, SITE: tl.constexpr):
    """a @ b with fp32 accumulation. PREC == 0x100 is bf16 operands; otherwise bit
    SITE of PREC selects 3xTF32 (spelled out by hand: Triton's built-in "tf32x3"
    lowering spills heavily) over plain TF32."""
    if PREC == 0x100:
        return tl.dot(a.to(tl.bfloat16), b.to(tl.bfloat16))
    elif (PREC >> SITE) & 1:
        a_hi, a_lo = _split_tf32(a)
        b_hi, b_lo = _split_tf32(b)
        acc = tl.dot(a_lo, b_hi, input_precision="tf32")
        acc = tl.dot(a_hi, b_lo, acc, input_precision="tf32")
        return tl.dot(a_hi, b_hi, acc, input_precision="tf32")
    else:
        return tl.dot(a, b, input_precision="tf32")


@triton.jit
def _gate(gam_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D: tl.constexpr):
    """E = exp(Gam), E^{-1} = exp(-Gam) on one [C, BD] tile."""
    gam = _load_vec(gam_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
    return tl.exp(gam), tl.exp(-gam)


@triton.jit
def _scores(
    v_ptr, k_ptr, gam_ptr, T, H, D, chunk_id, chunk_size, m_t,
    BLOCK_D: tl.constexpr, NUM_D: tl.constexpr, PREC: tl.constexpr,
):
    """(v * E) @ k'^T, [C, C], not masked."""
    S = tl.zeros((chunk_size, chunk_size), dtype=tl.float32)
    for i in tl.static_range(NUM_D):
        d0 = i * BLOCK_D
        e, e_inv = _gate(gam_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        v = _load_vec(v_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D) * e
        kp = _load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D) * e_inv
        S += _dot(v, tl.trans(kp), PREC, 0)
    return S


@triton.jit
def _vh(
    v_ptr, h_ptr, gam_ptr, T, H, D, chunk_id, chunk_size, d0, m_t,
    BLOCK_D: tl.constexpr, NUM_D: tl.constexpr, PREC: tl.constexpr,
):
    """((v * E) @ H_in)[:, d0:d0+BD]."""
    acc = tl.zeros((chunk_size, BLOCK_D), dtype=tl.float32)
    for j in tl.static_range(NUM_D):
        d1 = j * BLOCK_D
        gam = _load_vec(gam_ptr, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D)
        v = _load_vec(v_ptr, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D) * tl.exp(gam)
        h = _load_mat(h_ptr, D, d1, d0, BLOCK_D)
        acc += _dot(v, h, PREC, 1)
    return acc


# ---------------------------------------------------------------------------
# Forward
# ---------------------------------------------------------------------------
@triton.jit(do_not_specialize=["T"])
def trace_fwd_kernel(
    h_ptr, k_ptr, q_ptr, gam_ptr, coeff_ptr,
    x_ptr, o1_ptr, o2_ptr, o3_ptr, f_ptr,
    T, H: tl.constexpr, D: tl.constexpr, chunk_size: tl.constexpr,
    BLOCK_D: tl.constexpr, N: tl.constexpr, EPS: tl.constexpr, PREC: tl.constexpr,
):
    chunk_id = tl.program_id(0)
    bh = tl.program_id(1)
    b_id, h_id = bh // H, bh % H
    num_chunks = tl.cdiv(T, chunk_size)
    NUM_D: tl.constexpr = D // BLOCK_D
    m_t, tril = _masks(chunk_id, chunk_size, T)

    vec_off = (b_id * T * H + h_id) * D
    q_ptr += vec_off
    k_ptr += vec_off
    gam_ptr += vec_off
    x_ptr += vec_off
    o1_ptr += vec_off
    o2_ptr += vec_off
    o3_ptr += vec_off
    f_ptr += b_id * T * H + h_id
    h_ptr += ((b_id * num_chunks + chunk_id) * H + h_id).to(tl.int64) * D * D

    F = tl.zeros((chunk_size,), dtype=tl.float32)
    for i in tl.static_range(NUM_D):
        d0 = i * BLOCK_D
        e, e_inv = _gate(gam_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        kp = _load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D) * e_inv
        diag = _diag_of(_load_mat(h_ptr, D, d0, d0, BLOCK_D), BLOCK_D)
        F += tl.sum(e * e * (diag[None, :] + tl.cumsum(kp * kp, axis=0)), axis=1)
    F = tl.where(m_t, F + EPS, 0.0)
    _store_row(f_ptr, F, T, H, chunk_id, chunk_size)
    F = tl.where(m_t, F, 1.0)

    for m in tl.static_range(1, N):
        if m == 1:
            src = q_ptr
            dst = o1_ptr
        elif m == 2:
            src = o1_ptr
            dst = o2_ptr
        else:
            src = o2_ptr
            dst = o3_ptr
        S = tl.where(tril, _scores(src, k_ptr, gam_ptr, T, H, D, chunk_id, chunk_size, m_t,
                                   BLOCK_D, NUM_D, PREC), 0.0)
        for i in tl.static_range(NUM_D):
            d0 = i * BLOCK_D
            e, e_inv = _gate(gam_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            kp = _load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D) * e_inv
            inter = _vh(src, h_ptr, gam_ptr, T, H, D, chunk_id, chunk_size, d0, m_t,
                        BLOCK_D, NUM_D, PREC)
            out = (inter + _dot(S, kp, PREC, 2)) * e / F[:, None]
            _store_vec(dst, out, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
        tl.debug_barrier()

    c0 = tl.load(coeff_ptr + h_id * N + 0).to(tl.float32)
    c1 = tl.load(coeff_ptr + h_id * N + 1).to(tl.float32)
    c2 = tl.load(coeff_ptr + h_id * N + 2).to(tl.float32)
    for i in tl.static_range(NUM_D):
        d0 = i * BLOCK_D
        acc = c0 * _load_vec(q_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        acc += c1 * _load_vec(o1_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        acc += c2 * _load_vec(o2_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        if N > 3:
            c3 = tl.load(coeff_ptr + h_id * N + 3).to(tl.float32)
            acc += c3 * _load_vec(o3_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        _store_vec(x_ptr, acc, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)


# ---------------------------------------------------------------------------
# Backward
# ---------------------------------------------------------------------------
@triton.jit(do_not_specialize=["T"])
def trace_bwd_chunk_kernel(
    h_ptr, k_ptr, gam_ptr, q_ptr, o1_ptr, o2_ptr, o3_ptr, dx_ptr, f_ptr, coeff_ptr,
    p1_ptr, p2_ptr, p3_ptr, u1_ptr, u2_ptr, u3_ptr,
    dq_ptr, dk_ptr, dgk_ptr, g_partial_ptr, dcoeff_ptr,
    T, H: tl.constexpr, D: tl.constexpr, chunk_size: tl.constexpr,
    BLOCK_D: tl.constexpr, N: tl.constexpr, PREC: tl.constexpr,
):
    """Everything inside one chunk except the S_in term from later chunks.

    dk holds Z (low-rank part, before E^{-1}) and dgk holds the per-token
    linear term until the final pass.
    """
    chunk_id = tl.program_id(0)
    bh = tl.program_id(1)
    b_id, h_id = bh // H, bh % H
    num_chunks = tl.cdiv(T, chunk_size)
    NUM_D: tl.constexpr = D // BLOCK_D
    m_t, tril = _masks(chunk_id, chunk_size, T)

    scalar = b_id * T * H + h_id
    vec = scalar * D
    k_ptr += vec
    gam_ptr += vec
    q_ptr += vec
    o1_ptr += vec
    o2_ptr += vec
    o3_ptr += vec
    dx_ptr += vec
    p1_ptr += vec
    p2_ptr += vec
    p3_ptr += vec
    u1_ptr += vec
    u2_ptr += vec
    u3_ptr += vec
    dq_ptr += vec
    dk_ptr += vec
    dgk_ptr += vec
    f_ptr += scalar
    mat = ((b_id * num_chunks + chunk_id) * H + h_id).to(tl.int64) * D * D
    h_ptr += mat
    g_partial_ptr += mat

    F = _load_row(f_ptr, T, H, chunk_id, chunk_size, m_t, 1.0)
    c0 = tl.load(coeff_ptr + h_id * N + 0).to(tl.float32)
    c1 = tl.load(coeff_ptr + h_id * N + 1).to(tl.float32)
    c2 = tl.load(coeff_ptr + h_id * N + 2).to(tl.float32)
    c3 = 0.0
    if N > 3:
        c3 = tl.load(coeff_ptr + h_id * N + 3).to(tl.float32)

    # (1) p_{j+1} = p_j H / F, and Z += B_j^T Xt_j with B_j = tril((p_j E) k'^T).
    for j in tl.static_range(N - 1):
        if j == 0:
            src = dx_ptr
            dst = p1_ptr
        elif j == 1:
            src = p1_ptr
            dst = p2_ptr
        else:
            src = p2_ptr
            dst = p3_ptr
        ca = tl.load(coeff_ptr + h_id * N + j + 1).to(tl.float32)
        Bj = tl.where(tril, _scores(src, k_ptr, gam_ptr, T, H, D, chunk_id, chunk_size, m_t,
                                    BLOCK_D, NUM_D, PREC), 0.0)
        for i in tl.static_range(NUM_D):
            d0 = i * BLOCK_D
            e, e_inv = _gate(gam_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            kp = _load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D) * e_inv
            inter = _vh(src, h_ptr, gam_ptr, T, H, D, chunk_id, chunk_size, d0, m_t,
                        BLOCK_D, NUM_D, PREC)
            out = (inter + _dot(Bj, kp, PREC, 2)) * e / F[:, None]
            _store_vec(dst, out, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
            xt = ca * _load_vec(q_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            if j + 2 < N:
                cb = tl.load(coeff_ptr + h_id * N + j + 2).to(tl.float32)
                xt += cb * _load_vec(o1_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            if j + 3 < N:
                cc = tl.load(coeff_ptr + h_id * N + j + 3).to(tl.float32)
                xt += cc * _load_vec(o2_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            z = _dot(tl.trans(Bj), xt * e / F[:, None], PREC, 3)
            if j > 0:
                z += _load_vec(dk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            _store_vec(dk_ptr, z, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
        tl.debug_barrier()

    # (2) dq, u_m, alpha, dcoeff and lin = sum_m o_{m-1} w_m + do_m o_m.
    s = tl.zeros((chunk_size,), dtype=tl.float32)
    da = tl.zeros((1,), dtype=tl.float32)
    db = tl.zeros((1,), dtype=tl.float32)
    dc = tl.zeros((1,), dtype=tl.float32)
    dd = tl.zeros((1,), dtype=tl.float32)
    for i in tl.static_range(NUM_D):
        d0 = i * BLOCK_D
        q = _load_vec(q_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        o1 = _load_vec(o1_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        o2 = _load_vec(o2_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        dx = _load_vec(dx_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        p1 = _load_vec(p1_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        p2 = _load_vec(p2_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        dq = c0 * dx + c1 * p1 + c2 * p2
        do1 = c1 * dx + c2 * p1
        do2 = c2 * dx
        w1 = c1 * p1 + c2 * p2
        w2 = c2 * p1
        lin = q * w1 + do1 * o1 + o1 * w2 + do2 * o2
        if N > 3:
            o3 = _load_vec(o3_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            p3 = _load_vec(p3_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            dq += c3 * p3
            do1 += c3 * p2
            do2 += c3 * p1
            do3 = c3 * dx
            w1 += c3 * p3
            w2 += c3 * p2
            w3 = c3 * p1
            lin = q * w1 + do1 * o1 + o1 * w2 + do2 * o2 + o2 * w3 + do3 * o3
            _store_vec(u3_ptr, do3 / F[:, None], T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
            s += tl.sum(o3 * do3, axis=1)
            dd += tl.sum(tl.sum(dx * o3, axis=0), axis=0)
        _store_vec(dq_ptr, dq, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
        _store_vec(u1_ptr, do1 / F[:, None], T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
        _store_vec(u2_ptr, do2 / F[:, None], T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
        _store_vec(dgk_ptr, lin, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
        s += tl.sum(o1 * do1, axis=1) + tl.sum(o2 * do2, axis=1)
        da += tl.sum(tl.sum(dx * q, axis=0), axis=0)
        db += tl.sum(tl.sum(dx * o1, axis=0), axis=0)
        dc += tl.sum(tl.sum(dx * o2, axis=0), axis=0)
    alpha = tl.where(m_t, -s / F, 0.0)
    base = ((b_id * num_chunks + chunk_id) * H + h_id) * N
    tl.store(dcoeff_ptr + base + 0, tl.sum(da))
    tl.store(dcoeff_ptr + base + 1, tl.sum(db))
    tl.store(dcoeff_ptr + base + 2, tl.sum(dc))
    if N > 3:
        tl.store(dcoeff_ptr + base + 3, tl.sum(dd))
    tl.debug_barrier()

    # (3) Z += tril(X_m k'^T)^T Y_m.
    for m in tl.static_range(1, N):
        if m == 1:
            xs = q_ptr
            us = u1_ptr
        elif m == 2:
            xs = o1_ptr
            us = u2_ptr
        else:
            xs = o2_ptr
            us = u3_ptr
        A = tl.where(tril, _scores(xs, k_ptr, gam_ptr, T, H, D, chunk_id, chunk_size, m_t,
                                   BLOCK_D, NUM_D, PREC), 0.0)
        for i in tl.static_range(NUM_D):
            d0 = i * BLOCK_D
            e, e_inv = _gate(gam_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            y = _load_vec(us, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D) * e
            z = _load_vec(dk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            z += _dot(tl.trans(A), y, PREC, 4)
            _store_vec(dk_ptr, z, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
    tl.debug_barrier()

    # (4) trace term, E^{-1} on dk, suffix sums for dgk, g_partial = sum_m X_m^T Y_m + Diag(R_0).
    eye = tl.arange(0, BLOCK_D)
    for i in tl.static_range(NUM_D):
        d0 = i * BLOCK_D
        e, e_inv = _gate(gam_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        kp = _load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D) * e_inv
        ae2 = alpha[:, None] * e * e
        R = _suffix(ae2)
        diag = _diag_of(_load_mat(h_ptr, D, d0, d0, BLOCK_D), BLOCK_D)
        z = _load_vec(dk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        lin = _load_vec(dgk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        dgk = 0.5 * _suffix(lin - kp * z) + R * (diag[None, :] + _excl(kp * kp))
        _store_vec(dgk_ptr, dgk, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
        _store_vec(dk_ptr, (z + 2.0 * R * kp) * e_inv, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
        r0 = tl.sum(ae2, axis=0)
        for jd in tl.static_range(NUM_D):
            d1 = jd * BLOCK_D
            e1, _ = _gate(gam_ptr, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D)
            g = tl.zeros((BLOCK_D, BLOCK_D), dtype=tl.float32)
            for m in tl.static_range(1, N):
                if m == 1:
                    xs = q_ptr
                    us = u1_ptr
                elif m == 2:
                    xs = o1_ptr
                    us = u2_ptr
                else:
                    xs = o2_ptr
                    us = u3_ptr
                x = _load_vec(xs, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D) * e
                y = _load_vec(us, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D) * e1
                g += _dot(tl.trans(x), y, PREC, 5)
            if i == jd:
                g += tl.where(eye[:, None] == eye[None, :], r0[:, None], 0.0)
            _store_mat(g_partial_ptr, g, D, d0, d1, BLOCK_D)


@triton.jit
def _e_last_of(gam_ptr, b_id, h_id, cid, T, H: tl.constexpr, D: tl.constexpr,
               chunk_size: tl.constexpr, d0, BLOCK: tl.constexpr):
    """exp(Gam) at the last valid token of chunk ``cid``, dims d0:d0+BLOCK."""
    t_last = cid * chunk_size + tl.minimum(chunk_size, T - cid * chunk_size) - 1
    off = ((b_id * T + t_last) * H + h_id).to(tl.int64) * D + d0
    return tl.exp(tl.load(gam_ptr + off + tl.arange(0, BLOCK)).to(tl.float32))


@triton.jit(do_not_specialize=["T"])
def trace_bwd_scan_kernel(
    g_partial_ptr, gam_ptr, gin_ptr, dht_ptr,
    T, NC, H: tl.constexpr, D: tl.constexpr, chunk_size: tl.constexpr,
    BLOCK_S: tl.constexpr, HAS_DHT: tl.constexpr,
):
    """gin[c] = g_partial[c+1] + Diag(E_last[c+1]) gin[c+1] Diag(E_last[c+1])."""
    i_bh = tl.program_id(0)
    i_tile = tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H
    NUM_S: tl.constexpr = D // BLOCK_S
    r0 = (i_tile // NUM_S) * BLOCK_S
    c0 = (i_tile % NUM_S) * BLOCK_S
    G = tl.zeros((BLOCK_S, BLOCK_S), dtype=tl.float32)
    if HAS_DHT:
        p_dht = tl.make_block_ptr(
            dht_ptr + (i_b * H + i_h).to(tl.int64) * D * D,
            (D, D), (D, 1), (r0, c0), (BLOCK_S, BLOCK_S), (1, 0),
        )
        G = tl.load(p_dht, boundary_check=(0, 1)).to(tl.float32)
    last = NC - 1
    p_gin = tl.make_block_ptr(
        gin_ptr + ((i_b * NC + last) * H + i_h).to(tl.int64) * D * D,
        (D, D), (D, 1), (r0, c0), (BLOCK_S, BLOCK_S), (1, 0),
    )
    tl.store(p_gin, G.to(p_gin.dtype.element_ty), boundary_check=(0, 1))
    for it in tl.range(0, NC - 1):
        cid = NC - 2 - it
        src = cid + 1
        p_gp = tl.make_block_ptr(
            g_partial_ptr + ((i_b * NC + src) * H + i_h).to(tl.int64) * D * D,
            (D, D), (D, 1), (r0, c0), (BLOCK_S, BLOCK_S), (1, 0),
        )
        gp = tl.load(p_gp, boundary_check=(0, 1)).to(tl.float32)
        er = _e_last_of(gam_ptr, i_b, i_h, src, T, H, D, chunk_size, r0, BLOCK_S)
        ec = _e_last_of(gam_ptr, i_b, i_h, src, T, H, D, chunk_size, c0, BLOCK_S)
        G = gp + er[:, None] * G * ec[None, :]
        p_gin = tl.make_block_ptr(
            gin_ptr + ((i_b * NC + cid) * H + i_h).to(tl.int64) * D * D,
            (D, D), (D, 1), (r0, c0), (BLOCK_S, BLOCK_S), (1, 0),
        )
        tl.store(p_gin, G.to(p_gin.dtype.element_ty), boundary_check=(0, 1))


@triton.jit(do_not_specialize=["T"])
def trace_bwd_gin_kernel(
    h_ptr, k_ptr, gam_ptr, gin_ptr, dk_ptr, dgk_ptr,
    T, H: tl.constexpr, D: tl.constexpr, chunk_size: tl.constexpr,
    BLOCK_D: tl.constexpr, PREC: tl.constexpr,
):
    """Add S_in = Diag(E_C) (gin + gin^T) Diag(E_C) into dk and dgk."""
    chunk_id = tl.program_id(0)
    bh = tl.program_id(1)
    b_id, h_id = bh // H, bh % H
    num_chunks = tl.cdiv(T, chunk_size)
    NUM_D: tl.constexpr = D // BLOCK_D
    m_t, _ = _masks(chunk_id, chunk_size, T)

    gam_base = gam_ptr
    vec = (b_id * T * H + h_id) * D
    k_ptr += vec
    gam_ptr += vec
    dk_ptr += vec
    dgk_ptr += vec
    mat = ((b_id * num_chunks + chunk_id) * H + h_id).to(tl.int64) * D * D
    h_ptr += mat
    gin_ptr += mat

    for i in tl.static_range(NUM_D):
        d0 = i * BLOCK_D
        _, e_inv0 = _gate(gam_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        el0 = _e_last_of(gam_base, b_id, h_id, chunk_id, T, H, D, chunk_size, d0, BLOCK_D)
        Za = tl.zeros((chunk_size, BLOCK_D), dtype=tl.float32)
        v1 = tl.zeros((BLOCK_D,), dtype=tl.float32)
        for j in tl.static_range(NUM_D):
            d1 = j * BLOCK_D
            _, e_inv1 = _gate(gam_ptr, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D)
            kp1 = _load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D) * e_inv1
            el1 = _e_last_of(gam_base, b_id, h_id, chunk_id, T, H, D, chunk_size, d1, BLOCK_D)
            sym = _load_mat(gin_ptr, D, d1, d0, BLOCK_D) + tl.trans(_load_mat(gin_ptr, D, d0, d1, BLOCK_D))
            Za += _dot(kp1 * el1[None, :], sym, PREC, 6)
            h_ij = _load_mat(h_ptr, D, d0, d1, BLOCK_D)
            v1 += tl.sum(tl.trans(sym) * el1[None, :] * h_ij, axis=1)
        Za = Za * el0[None, :]
        dk = _load_vec(dk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        _store_vec(dk_ptr, dk + e_inv0 * Za, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
        kp0 = _load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D) * e_inv0
        dgk = _load_vec(dgk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        dgk += 0.5 * (v1[None, :] * el0[None, :] + _excl(kp0 * Za))
        _store_vec(dgk_ptr, dgk, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)


def _bwd(k, q, os, dx, F, coeff_h, gam, h, dht, h0, chunk_size, n_coeff):
    """os = (o1, o2[, o3]) in fp32."""
    B, T, H, D = q.shape
    C = chunk_size
    N = n_coeff
    nc = triton.cdiv(T, C)
    block_d = _choose_block_d(D)
    f32 = dict(device=q.device, dtype=torch.float32)
    o1, o2 = os[0], os[1]
    o3 = os[2] if N == 4 else o2
    p1 = torch.empty(B, T, H, D, **f32)
    p2 = torch.empty(B, T, H, D, **f32)
    p3 = torch.empty(B, T, H, D, **f32) if N == 4 else p2
    u1 = torch.empty(B, T, H, D, **f32)
    u2 = torch.empty(B, T, H, D, **f32)
    u3 = torch.empty(B, T, H, D, **f32) if N == 4 else u2
    dq = torch.empty_like(q)
    dk = torch.empty(B, T, H, D, **f32)
    dgk = torch.empty(B, T, H, D, **f32)
    g_partial = torch.empty(B, nc, H, D, D, **f32)
    gin = torch.empty(B, nc, H, D, D, **f32)
    dcoeff_part = torch.empty(B, nc, H, N, **f32)
    grid = (nc, B * H)
    trace_bwd_chunk_kernel[grid](
        h, k, gam, q, o1, o2, o3, dx, F, coeff_h,
        p1, p2, p3, u1, u2, u3,
        dq, dk, dgk, g_partial, dcoeff_part,
        T, H, D, C, block_d, N, DOT_PRECISION,
        num_warps=8, num_stages=1,
    )
    block_s = _choose_scan_block(D)
    num_s = D // block_s
    dht_buf = dht.float().contiguous() if dht is not None else gin.new_empty(1)
    trace_bwd_scan_kernel[(B * H, num_s * num_s)](
        g_partial, gam, gin, dht_buf,
        T, nc, H, D, C, block_s, int(dht is not None),
        num_warps=1, num_stages=1,
    )
    trace_bwd_gin_kernel[grid](
        h, k, gam, gin, dk, dgk,
        T, H, D, C, block_d, DOT_PRECISION, num_warps=8, num_stages=1,
    )
    dh0 = None
    if h0 is not None:
        e0 = gam[:, min(C, T) - 1].exp()
        dh0 = g_partial[:, 0] + e0[..., :, None] * gin[:, 0] * e0[..., None, :]
        dh0 = dh0.to(h0.dtype)
    return dq, dk, dgk, dcoeff_part, dh0


class q_kkt_solve_trace_triton(torch.autograd.Function):
    """x, H_T = phi(q, k, gk) with F = tr(H) and per-dimension decay.

    apply(k, q, gk, chunk_size, coeff, h0) -> (x [B, T, H, D], H_T [B, H, D, D])
    coeff is [N] or [H, N], N = 3 or 4. chunk_size must be a power of two.
    """

    @staticmethod
    def forward(ctx, k, q, gk=None, chunk_size: int = 64, coeff=(1.0, -0.5, 0.375), h0=None):
        if q.ndim != 4:
            raise ValueError(f"q must be [B, T, H, D], got {tuple(q.shape)}")
        if chunk_size != 2 ** (chunk_size.bit_length() - 1):
            raise ValueError(f"chunk_size must be a power of 2, got {chunk_size}")
        k = k.contiguous()
        q = q.contiguous()
        B, T, H, D = q.shape
        coeff_is_tensor = torch.is_tensor(coeff)
        coeff_shape = tuple(coeff.shape) if coeff_is_tensor else None
        coeff_dtype = coeff.dtype if coeff_is_tensor else None
        coeff_h = _normalize_coeff(coeff, H, q.device)
        n_coeff = coeff_h.shape[-1]

        if gk is None:
            gam = torch.zeros(B, T, H, D, device=q.device, dtype=torch.float32)
            gk_arg = gv_arg = None
        else:
            gk = gk.contiguous()
            gam = chunk_local_cumsum(gk, chunk_size=chunk_size, scale=0.5, output_dtype=torch.float32)
            gk_arg = gv_arg = gam
        h, ht = chunk_fwd_h(
            k=k, v=k, gk=gk_arg, gv=gv_arg, h0=h0,
            output_final_state=True, chunk_size=chunk_size, states_in_fp32=True,
        )
        f32 = dict(device=q.device, dtype=torch.float32)
        x = torch.empty_like(q)
        o1 = torch.empty(B, T, H, D, **f32)
        o2 = torch.empty(B, T, H, D, **f32)
        o3 = torch.empty(B, T, H, D, **f32) if n_coeff == 4 else o2
        F = torch.empty(B, T, H, **f32)
        trace_fwd_kernel[(triton.cdiv(T, chunk_size), B * H)](
            h, k, q, gam, coeff_h, x, o1, o2, o3, F,
            T, H, D, chunk_size, _choose_block_d(D), n_coeff, EPS, DOT_PRECISION,
            num_warps=8 if DOT_PRECISION & 0x7F else 4, num_stages=1,
        )

        saved = [k, q, o1, o2, F, coeff_h, h, gam]
        if n_coeff == 4:
            saved.append(o3)
        if gk is not None:
            saved.append(gk)
        if h0 is not None:
            saved.append(h0)
        ctx.save_for_backward(*saved)
        ctx.chunk_size = chunk_size
        ctx.n_coeff = n_coeff
        ctx.has_gk = gk is not None
        ctx.has_h0 = h0 is not None
        ctx.coeff_is_tensor = coeff_is_tensor
        ctx.coeff_shape = coeff_shape
        ctx.coeff_dtype = coeff_dtype
        return x, ht

    @staticmethod
    def backward(ctx, dx, dht=None):
        saved = list(ctx.saved_tensors)
        k, q, o1, o2, F, coeff_h, h, gam = saved[:8]
        idx = 8
        o3 = saved[idx] if ctx.n_coeff == 4 else None
        idx += int(ctx.n_coeff == 4)
        gk = saved[idx] if ctx.has_gk else None
        idx += int(ctx.has_gk)
        h0 = saved[idx] if ctx.has_h0 else None
        os_ = [o1, o2] + ([o3] if o3 is not None else [])
        dq, dk, dgk, dcoeff_part, dh0 = _bwd(
            k, q, os_, dx.contiguous(), F, coeff_h, gam, h,
            None if dht is None else dht.contiguous(), h0, ctx.chunk_size, ctx.n_coeff,
        )
        dcoeff = None
        if ctx.coeff_is_tensor and ctx.needs_input_grad[4]:
            dcoeff_h = dcoeff_part.sum(dim=(0, 1))
            if len(ctx.coeff_shape) == 1:
                dcoeff_h = dcoeff_h.sum(0)
            dcoeff = dcoeff_h.to(ctx.coeff_dtype).reshape(ctx.coeff_shape)
        dgk_out = dgk.to(gk.dtype) if gk is not None else None
        return dk.to(k.dtype), dq, dgk_out, None, dcoeff, dh0
