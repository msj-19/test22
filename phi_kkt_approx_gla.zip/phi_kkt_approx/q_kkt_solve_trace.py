"""Trace-normalized phi-KKT solve with symmetric per-dimension (vector) decay.

Model, per batch and head (D = head dim, N = number of polynomial coefficients):

    H_t = M_t H_{t-1} M_t + k_t k_t^T,      M_t = Diag(exp(gk_t / 2)),  gk_t in R^D
    F_t = tr(H_t)
    o_0 = q_t,   o_m = o_{m-1} H_t / F_t    (m = 1 .. N-1)
    x_t = sum_m coeff[m] * o_m

N = 3 is the abc variant, N = 4 the abcd variant. A constant gate gk_t = g * 1
reduces to the old scalar update H_t = e^g H_{t-1} + k_t k_t^T. H_t stays
symmetric PSD, so H_t / tr(H_t) has its spectrum in [0, 1].

Chunk form. Inside one chunk (local step t = 1..C, H_in = state before the chunk):

    Gam_t = 0.5 * sum_{j<=t} gk_j            chunk-local, per dim
    E_t   = exp(Gam_t),   k'_i = k_i * exp(-Gam_i)
    H_t   = Diag(E_t) (H_in + sum_{i<=t} k'_i k'_i^T) Diag(E_t)

    v H_t     = [ (v*E_t) H_in + sum_{i<=t} ((v*E_t) . k'_i) k'_i ] * E_t
    diag(H_t) = E_t^2 * (diag(H_in) + sum_{i<=t} k'_i^2)

Backward. With do_m = dL/do_m and u_m = do_m / F:

    dq      = sum_j coeff[j] dx H^j / F^j              (H symmetric => self-adjoint)
    dH_t    = sum_{m>=1} o_{m-1}^T u_m + alpha_t I,    alpha_t = -sum_m <o_m, do_m> / F_t
    G_t     = dH_t + M_{t+1} G_{t+1} M_{t+1}           (G_T += dL/dH_T)
    dk_t    = (G_t + G_t^T) k_t
    dgk_t   = 0.5 * rowsum((G_t + G_t^T) * M_t H_{t-1} M_t)

In chunk coordinates (G_in = gradient reaching the chunk's last state from later
chunks, X_m = o_{m-1} * E, Y_m = u_m * E, R_t = sum_{s>=t} alpha_s E_s^2):

    G^_t   = E_C G_in E_C + sum_{s>=t} (sum_m X_m,s^T Y_m,s) + Diag(R_t)
    S^_t   = G^_t + G^_t^T
    dk_t   = exp(-Gam_t) * (S^_t k'_t)
    dgk_t  = 0.5 * rowsum(S^_t * (H_in + sum_{i<t} k'_i k'_i^T))
    g_partial = sum_t E_t dH_t E_t   (gradient w.r.t. H_in from this chunk)
    gin[c-1]  = g_partial[c] + E_C gin[c] E_C

Every piece is a [C, C] x [C, D] or [C, D] x [D, D] matmul, plus cumsums along C.

This file is the PyTorch reference of the chunk algorithm. Each ``_fwd_*`` /
``_bwd_*`` function maps to one future Triton kernel. Chunked tensors use the
layout [B, H, NC, C, D]. h0 must be symmetric (it is a k k^T state).
"""
from typing import List, Optional, Sequence, Tuple, Union

import torch
import torch.nn.functional as tnf

EPS = 1e-12


# ---------------------------------------------------------------------------
# Layout helpers
# ---------------------------------------------------------------------------
def _acc(x: torch.Tensor) -> torch.Tensor:
    """Promote to at least fp32 (keeps fp64 for gradient checks)."""
    return x.to(torch.promote_types(x.dtype, torch.float32))


def _to_chunks(x: torch.Tensor, C: int) -> torch.Tensor:
    """[B, T, H, D] -> [B, H, NC, C, D]. Zero padding is harmless: k = 0 adds
    nothing to H and gk = 0 means no decay, so padded steps keep H unchanged."""
    B, T, H, D = x.shape
    NC = (T + C - 1) // C
    pad = NC * C - T
    if pad:
        x = tnf.pad(x, (0, 0, 0, 0, 0, pad))
    return x.view(B, NC, C, H, D).permute(0, 3, 1, 2, 4).contiguous()


def _from_chunks(x: torch.Tensor, T: int) -> torch.Tensor:
    """[B, H, NC, C, D] -> [B, T, H, D]."""
    B, H, NC, C, D = x.shape
    return x.permute(0, 2, 3, 1, 4).reshape(B, NC * C, H, D)[:, :T]


def _rev_cumsum(x: torch.Tensor) -> torch.Tensor:
    """Inclusive suffix sum along the chunk axis: out_t = sum_{s>=t} x_s."""
    return x.flip(-2).cumsum(-2).flip(-2)


def _excl_cumsum(x: torch.Tensor) -> torch.Tensor:
    """Exclusive prefix sum along the chunk axis: out_t = sum_{i<t} x_i."""
    return tnf.pad(x.cumsum(-2), (0, 0, 1, 0))[..., :-1, :]


def _coeff_heads(
    coeff: Union[torch.Tensor, Sequence[float]],
    H: int,
    device: torch.device,
    dtype: torch.dtype,
    keep_grad: bool = False,
) -> torch.Tensor:
    """Broadcast [N] (shared) or [H, N] (per head) coefficients to [H, N]."""
    if torch.is_tensor(coeff):
        t = coeff if keep_grad else coeff.detach()
    else:
        t = torch.tensor(list(coeff))
    t = t.to(device=device, dtype=dtype)
    if t.dim() == 1:
        t = t.reshape(1, -1).expand(H, -1)
    if t.dim() != 2 or t.shape[0] != H:
        raise ValueError(f"coeff must be [N] or [H, N] with H={H}, got {tuple(t.shape)}")
    return t


# ---------------------------------------------------------------------------
# Shared chunk math
# ---------------------------------------------------------------------------
def _gate_terms(gk_c: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Half-gate cumsum. E = exp(Gam), E_inv = exp(-Gam), E_last = E at the
    chunk end. exp(-Gam) can grow inside a chunk; halving the gate keeps it at
    exp(|sum gk| / 2)."""
    gam = 0.5 * gk_c.cumsum(dim=-2)
    E = gam.exp()
    E_inv = (-gam).exp()
    return E, E_inv, E[..., -1, :]


def _causal_masks(C: int, device, dtype) -> Tuple[torch.Tensor, torch.Tensor]:
    """mask[t, i] = 1 for i <= t; strict[t, i] = 1 for i < t."""
    ones = torch.ones(C, C, device=device, dtype=dtype)
    return ones.tril(), ones.tril(-1)


def _apply_H(
    v: torch.Tensor,
    h_in: torch.Tensor,
    kp: torch.Tensor,
    E: torch.Tensor,
    mask: torch.Tensor,
) -> torch.Tensor:
    """v_t H_t for every step of every chunk.

    v_t H_t = [ (v_t*E_t) H_in + sum_{i<=t} ((v_t*E_t) . k'_i) k'_i ] * E_t
    """
    vt = v * E                                   # Diag(E_t) folded into the left operand
    inter = vt @ h_in                            # chunk-start state:   [C, D] x [D, D]
    scores = (vt @ kp.transpose(-1, -2)) * mask  # gated causal scores: [C, D] x [D, C]
    intra = scores @ kp                          # in-chunk keys:       [C, C] x [C, D]
    return (inter + intra) * E                   # Diag(E_t) on the right side


# ---------------------------------------------------------------------------
# Forward steps
# ---------------------------------------------------------------------------
def _fwd_chunk_states(
    kp: torch.Tensor, E_last: torch.Tensor, h0: Optional[torch.Tensor]
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Step F1: state before each chunk, plus the final state.

    Triton: chunk_fwd_h(k=k, v=k, g=None, gk=Gam, gv=Gam), which applies the
    decay on both the K and V side of the [D, D] state.
    H_end = Diag(E_C) (H_in + K'^T K') Diag(E_C)
    """
    B, H, NC, C, D = kp.shape
    h = _acc(h0).to(kp.dtype) if h0 is not None else kp.new_zeros(B, H, D, D)
    h_in = []
    for c in range(NC):
        h_in.append(h)
        kc = kp[:, :, c]
        h = E_last[:, :, c, :, None] * (h + kc.transpose(-1, -2) @ kc) * E_last[:, :, c, None, :]
    return torch.stack(h_in, dim=2), h


def _fwd_trace(h_in: torch.Tensor, kp: torch.Tensor, E: torch.Tensor) -> torch.Tensor:
    """Step F2: F_t = tr(H_t) for every step, [B, H, NC, C].

    diag(H_t) follows its own 1D recurrence d_t = exp(gk_t) d_{t-1} + k_t^2,
    written in chunk form as E_t^2 * (diag(H_in) + cumsum(k'^2)). O(C D).
    """
    diag_in = torch.diagonal(h_in, dim1=-2, dim2=-1)                  # [B, H, NC, D]
    diag_t = E.square() * (diag_in.unsqueeze(-2) + kp.square().cumsum(-2))
    return diag_t.sum(-1) + EPS


def _fwd_poly(
    q_c: torch.Tensor,
    h_in: torch.Tensor,
    kp: torch.Tensor,
    E: torch.Tensor,
    mask: torch.Tensor,
    Fv: torch.Tensor,
    coeff_h: torch.Tensor,
) -> Tuple[torch.Tensor, List[torch.Tensor]]:
    """Step F3: o_m = o_{m-1} H / F and x = sum_m coeff[m] o_m.

    Triton: one kernel over (num_chunks, B*H), fused with step F2.
    Returns x and [o_0 = q, o_1, ..., o_{N-1}].
    """
    H, N = coeff_h.shape
    os = [q_c]
    for _ in range(1, N):
        os.append(_apply_H(os[-1], h_in, kp, E, mask) / Fv[..., None])
    x = sum(coeff_h[:, m].view(1, H, 1, 1, 1) * os[m] for m in range(N))
    return x, os


# ---------------------------------------------------------------------------
# Backward steps
# ---------------------------------------------------------------------------
def _bwd_poly(
    dx_c: torch.Tensor,
    os: List[torch.Tensor],
    h_in: torch.Tensor,
    kp: torch.Tensor,
    E: torch.Tensor,
    mask: torch.Tensor,
    Fv: torch.Tensor,
    coeff_h: torch.Tensor,
):
    """Step B1: gradients through the polynomial at fixed H and F.

    p_j  = dx H^j / F^j      (same kernel as F3 run on dx: H is symmetric)
    do_m = sum_{j=0}^{N-1-m} coeff[m+j] p_j,   dq = do_0
    u_m  = do_m / F                 -> low-rank part of dH: sum_m o_{m-1}^T u_m
    alpha = -sum_{m>=1} <o_m, do_m> / F   (dL/dF, enters dH as alpha * I)
    dcoeff[m] = sum <o_m, dx>
    """
    H, N = coeff_h.shape
    Fe = Fv[..., None]
    p = [dx_c]
    for _ in range(1, N):
        p.append(_apply_H(p[-1], h_in, kp, E, mask) / Fe)
    do = [
        sum(coeff_h[:, m + j].view(1, H, 1, 1, 1) * p[j] for j in range(N - m))
        for m in range(N)
    ]
    dq = do[0]
    u = [None] + [do[m] / Fe for m in range(1, N)]
    alpha = -sum((os[m] * do[m]).sum(-1) for m in range(1, N)) / Fv
    dcoeff = torch.stack([(os[m] * dx_c).sum(dim=(0, 2, 3, 4)) for m in range(N)], dim=-1)
    return dq, u, alpha, dcoeff


def _bwd_chunk_partial(
    os: List[torch.Tensor],
    u: List[torch.Tensor],
    alpha: torch.Tensor,
    E: torch.Tensor,
):
    """Step B2: per-chunk factors and g_partial = sum_t E_t dH_t E_t.

    X_m = o_{m-1} * E,  Y_m = u_m * E     (E_t dH_t E_t low-rank = sum_m X_m^T Y_m)
    R_t = sum_{s>=t} alpha_s E_s^2        (E_t (alpha_t I) E_t = Diag(alpha_t E_t^2))
    g_partial = sum_m X_m^T Y_m + Diag(R_1)
    """
    N = len(os)
    X = [os[m - 1] * E for m in range(1, N)]
    Y = [u[m] * E for m in range(1, N)]
    R = _rev_cumsum(alpha[..., None] * E.square())
    g_partial = torch.diag_embed(R[..., 0, :])
    for Xm, Ym in zip(X, Y):
        g_partial = g_partial + Xm.transpose(-1, -2) @ Ym
    return X, Y, R, g_partial


def _bwd_state_scan(
    g_partial: torch.Tensor, E_last: torch.Tensor, dht: Optional[torch.Tensor]
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Step B3: reverse scan over chunks.

    gin[c]   = gradient reaching the last state of chunk c from later chunks
    gin[-1]  = dL/dH_T
    gin[c-1] = g_partial[c] + Diag(E_C[c]) gin[c] Diag(E_C[c])
    dh0      = g_partial[0] + Diag(E_C[0]) gin[0] Diag(E_C[0])

    Triton: tiles stay independent; tile (r, c) needs E_C[r] and E_C[c].
    """
    B, H, NC, D, _ = g_partial.shape
    g = _acc(dht).to(g_partial.dtype) if dht is not None else g_partial.new_zeros(B, H, D, D)
    gin = [None] * NC
    for c in reversed(range(NC)):
        gin[c] = g
        g = g_partial[:, :, c] + E_last[:, :, c, :, None] * g * E_last[:, :, c, None, :]
    return torch.stack(gin, dim=2), g


def _bwd_dk_dgk(
    X: List[torch.Tensor],
    Y: List[torch.Tensor],
    R: torch.Tensor,
    gin: torch.Tensor,
    h_in: torch.Tensor,
    kp: torch.Tensor,
    E_inv: torch.Tensor,
    E_last: torch.Tensor,
    mask: torch.Tensor,
    strict: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Step B4: dk and dgk inside each chunk.

    S^_t = S_in + sum_{s>=t} sum_m (X^T Y + Y^T X)_s + 2 Diag(R_t)
    S_in = E_C (gin + gin^T) E_C
    dk_t  = exp(-Gam_t) * (S^_t k'_t)
    dgk_t = 0.5 * rowsum(S^_t * (H_in + sum_{i<t} k'_i k'_i^T))
    Uses rowsum((x y^T) * (z z^T)) = (x * z) (y . z).
    """
    kpT = kp.transpose(-1, -2)
    S_in = E_last[..., :, None] * (gin + gin.transpose(-1, -2)) * E_last[..., None, :]

    # ---- dk ---------------------------------------------------------------
    # (a) later chunks: rows of S_in k'_t (S_in is symmetric).
    Za = kp @ S_in
    # (c) trace term: 2 Diag(R_t) k'_t.
    acc = Za + 2.0 * R * kp
    # (b) low-rank terms, s >= t:
    #     sum_s X_s (Y_s . k'_t) + Y_s (X_s . k'_t)
    #     = (tril(Y K'^T))^T X + (tril(X K'^T))^T Y   with [s, t] indexing.
    for Xm, Ym in zip(X, Y):
        acc = acc + ((Ym @ kpT) * mask).transpose(-1, -2) @ Xm
        acc = acc + ((Xm @ kpT) * mask).transpose(-1, -2) @ Ym
    dk = E_inv * acc

    # ---- dgk --------------------------------------------------------------
    h_in_T = h_in.transpose(-1, -2)
    diag_in = torch.diagonal(h_in, dim1=-2, dim2=-1).unsqueeze(-2)     # [B, H, NC, 1, D]

    # (1) S_in against H_in: one D-vector per chunk, the same for every t.
    v1 = (S_in * h_in).sum(-1).unsqueeze(-2)
    # (2) S_in against sum_{i<t} k'_i k'_i^T: exclusive cumsum of k'_i * (S_in k'_i).
    v2 = _excl_cumsum(kp * Za)
    # (3) low-rank (s >= t) against H_in: suffix sum of X * (Y H_in^T) + Y * (X H_in^T).
    low_h = 0.0
    for Xm, Ym in zip(X, Y):
        low_h = low_h + Xm * (Ym @ h_in_T) + Ym * (Xm @ h_in_T)
    v3 = _rev_cumsum(low_h)
    # (4) low-rank (s >= t) against in-chunk keys (i < t): corner sums
    #     CS_t = sum_{s>=t} sum_{i<t} P_s * k'_i * M[s, i],  M = Q K'^T,
    #     computed from CS_t - CS_{t+1} = P_t * (strict(M) K')_t - k'_t * (strict(M)^T P)_t.
    #     Both orders (P, Q) = (X, Y) and (Y, X) appear.
    delta = 0.0
    for Xm, Ym in zip(X, Y):
        for Pm, Qm in ((Xm, Ym), (Ym, Xm)):
            Ms = (Qm @ kpT) * strict
            delta = delta + Pm * (Ms @ kp) - kp * (Ms.transpose(-1, -2) @ Pm)
    v4 = _rev_cumsum(delta)
    # (5) trace term 2 Diag(R_t) against diag(H_in + sum_{i<t} k'_i^2).
    v5 = 2.0 * R * (diag_in + _excl_cumsum(kp.square()))

    dgk = 0.5 * (v1 + v2 + v3 + v4 + v5)
    return dk, dgk


# ---------------------------------------------------------------------------
# Autograd
# ---------------------------------------------------------------------------
class q_kkt_solve_trace(torch.autograd.Function):
    """x_t = sum_m coeff[m] q_t (H_t / tr H_t)^m with vector decay gk [B, T, H, D].

    apply(k, q, gk, chunk_size, coeff, h0) -> (x [B, T, H, D], H_T [B, H, D, D])
    coeff: [N] (shared over heads) or [H, N]; N = 3 (abc) or 4 (abcd).
    """

    @staticmethod
    def forward(
        ctx,
        k: torch.Tensor,
        q: torch.Tensor,
        gk: Optional[torch.Tensor] = None,
        chunk_size: int = 64,
        coeff: Union[torch.Tensor, Sequence[float]] = (1.0, -0.5, 0.375),
        h0: Optional[torch.Tensor] = None,
    ):
        B, T, H, D = q.shape
        C = chunk_size
        dt = torch.promote_types(q.dtype, torch.float32)
        coeff_h = _coeff_heads(coeff, H, q.device, dt)

        # Inputs in chunk layout, fp32 (or fp64).
        q_c = _to_chunks(q.to(dt), C)
        k_c = _to_chunks(k.to(dt), C)
        gk_c = _to_chunks(gk.to(dt), C) if gk is not None else torch.zeros_like(k_c)

        # Gate factors and decayed keys k' = k * exp(-Gam).
        E, E_inv, E_last = _gate_terms(gk_c)
        kp = k_c * E_inv
        mask, _ = _causal_masks(C, q.device, dt)

        # F1: chunk-start states.  F2: trace.  F3: polynomial apply.
        h_in, h_final = _fwd_chunk_states(kp, E_last, h0)
        Fv = _fwd_trace(h_in, kp, E)
        x_c, os = _fwd_poly(q_c, h_in, kp, E, mask, Fv, coeff_h)

        # Saved for backward: inputs, chunk states, F, and o_1..o_{N-1}.
        ctx.save_for_backward(k, q, gk, h0, coeff_h, h_in, Fv, *os[1:])
        ctx.chunk_size = C
        ctx.coeff_is_tensor = torch.is_tensor(coeff)
        ctx.coeff_shape = tuple(coeff.shape) if torch.is_tensor(coeff) else None
        ctx.coeff_dtype = coeff.dtype if torch.is_tensor(coeff) else None
        return _from_chunks(x_c, T).to(q.dtype), h_final

    @staticmethod
    def backward(ctx, dx: torch.Tensor, dht: Optional[torch.Tensor] = None):
        k, q, gk, h0, coeff_h, h_in, Fv, *os_saved = ctx.saved_tensors
        B, T, H, D = q.shape
        C = ctx.chunk_size
        dt = coeff_h.dtype

        # Recompute the cheap per-chunk gate factors.
        q_c = _to_chunks(q.to(dt), C)
        k_c = _to_chunks(k.to(dt), C)
        gk_c = _to_chunks(gk.to(dt), C) if gk is not None else torch.zeros_like(k_c)
        E, E_inv, E_last = _gate_terms(gk_c)
        kp = k_c * E_inv
        mask, strict = _causal_masks(C, q.device, dt)
        os = [q_c] + list(os_saved)
        dx_c = _to_chunks(dx.to(dt), C)

        # B1: polynomial gradients (dq, u_m, alpha, dcoeff).
        dq_c, u, alpha, dcoeff_h = _bwd_poly(dx_c, os, h_in, kp, E, mask, Fv, coeff_h)
        # B2: per-chunk factors and gradient w.r.t. each chunk-start state.
        X, Y, R, g_partial = _bwd_chunk_partial(os, u, alpha, E)
        # B3: reverse scan of the [D, D] gradient across chunks.
        gin, dh0 = _bwd_state_scan(g_partial, E_last, dht)
        # B4: dk and dgk inside every chunk.
        dk_c, dgk_c = _bwd_dk_dgk(X, Y, R, gin, h_in, kp, E_inv, E_last, mask, strict)

        dk = _from_chunks(dk_c, T).to(k.dtype)
        dq = _from_chunks(dq_c, T).to(q.dtype)
        dgk = _from_chunks(dgk_c, T).to(gk.dtype) if gk is not None else None
        dh0 = dh0.to(h0.dtype) if h0 is not None else None

        dcoeff = None
        if ctx.coeff_is_tensor and ctx.needs_input_grad[4]:
            # [N] coefficients are shared over heads, so their gradient is summed.
            dcoeff = dcoeff_h.sum(0) if len(ctx.coeff_shape) == 1 else dcoeff_h
            dcoeff = dcoeff.to(ctx.coeff_dtype).reshape(ctx.coeff_shape)
        return dk, dq, dgk, None, dcoeff, dh0


# ---------------------------------------------------------------------------
# Step-by-step reference (also the decoding update)
# ---------------------------------------------------------------------------
def trace_kkt_recurrent_step(
    q_t: torch.Tensor,
    k_t: torch.Tensor,
    gk_t: Optional[torch.Tensor],
    coeff_h: torch.Tensor,
    state: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """One decoding step. q_t, k_t, gk_t: [B, H, D]; coeff_h: [H, N]; state: [B, H, D, D]."""
    # H_t = M_t H_{t-1} M_t + k_t k_t^T with M_t = Diag(exp(gk_t / 2)).
    if gk_t is not None:
        mu = torch.exp(0.5 * gk_t)
        state = mu[..., :, None] * state * mu[..., None, :]
    state = state + k_t[..., :, None] * k_t[..., None, :]
    # F_t = tr(H_t).
    Fv = torch.diagonal(state, dim1=-2, dim2=-1).sum(-1, keepdim=True) + EPS
    # x_t = sum_m coeff[m] o_m with o_m = o_{m-1} H_t / F_t.
    o = q_t
    x = coeff_h[:, 0].view(1, -1, 1) * o
    for m in range(1, coeff_h.shape[1]):
        o = (o.unsqueeze(-2) @ state).squeeze(-2) / Fv
        x = x + coeff_h[:, m].view(1, -1, 1) * o
    return x, state


def trace_kkt_reference(
    q: torch.Tensor,
    k: torch.Tensor,
    gk: Optional[torch.Tensor],
    coeff: Union[torch.Tensor, Sequence[float]],
    h0: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Plain recurrence over T; differentiable through torch autograd."""
    B, T, H, D = q.shape
    dt = torch.promote_types(q.dtype, torch.float32)
    coeff_h = _coeff_heads(coeff, H, q.device, dt, keep_grad=True)
    state = h0.to(dt) if h0 is not None else q.new_zeros(B, H, D, D, dtype=dt)
    xs = []
    for t in range(T):
        x_t, state = trace_kkt_recurrent_step(
            q[:, t].to(dt),
            k[:, t].to(dt),
            gk[:, t].to(dt) if gk is not None else None,
            coeff_h,
            state,
        )
        xs.append(x_t)
    return torch.stack(xs, dim=1).to(q.dtype), state


def _check_against_reference(B=2, T=37, H=2, D=16, N=3, C=16, seed=0):
    """fp64 comparison of the chunk algorithm with the plain recurrence."""
    torch.manual_seed(seed)
    f64 = dict(dtype=torch.float64)
    q = torch.randn(B, T, H, D, **f64).requires_grad_()
    k = (torch.randn(B, T, H, D, **f64) / D ** 0.5).requires_grad_()
    gk = (tnf.logsigmoid(torch.randn(B, T, H, D, **f64)) / 4).requires_grad_()
    coeff = torch.randn(H, N, **f64).requires_grad_()
    a = torch.randn(B, H, D, D, **f64) / D
    h0 = (a @ a.transpose(-1, -2)).requires_grad_()
    dx = torch.randn(B, T, H, D, **f64)
    dht = torch.randn(B, H, D, D, **f64)

    inputs = (q, k, gk, coeff, h0)
    x1, s1 = q_kkt_solve_trace.apply(k, q, gk, C, coeff, h0)
    g1 = torch.autograd.grad((x1 * dx).sum() + (s1 * dht).sum(), inputs)
    x2, s2 = trace_kkt_reference(q, k, gk, coeff, h0)
    g2 = torch.autograd.grad((x2 * dx).sum() + (s2 * dht).sum(), inputs)

    print("x     max err:", (x1 - x2).abs().max().item())
    print("H_T   max err:", (s1 - s2).abs().max().item())
    for name, a1, a2 in zip(("dq", "dk", "dgk", "dcoeff", "dh0"), g1, g2):
        print(f"{name:6s} max err:", (a1 - a2).abs().max().item())


if __name__ == "__main__":
    _check_against_reference(N=3)
    _check_against_reference(N=4, T=50, C=8, seed=1)
