"""Store-o3 fork of ``q_kkt_solve_abcd_fast``.

Do not edit ``q_kkt_solve_abcd_fast.py``. Change vs that file:

Forward already stored o1 / o2; this fork also writes
``o3 = (o2 @ H) / F`` to a [B, L, H, D] buffer. Backward loads it for
``alpha`` / ``dabcd`` instead of reconstructing
``o3 = (x - a q - b o1 - c o2) / d``, which overflows when ``d`` is near 0.
"""
from typing import Optional, Sequence, Tuple, Union
import time
import torch
import triton
import triton.language as tl


from fla.ops.common.chunk_h import chunk_fwd_h
from fla.ops.utils import chunk_local_cumsum
from fla.ops.utils.op import exp


def _choose_block_d(D: int) -> int:
    """Tile width along D. D=64 stays one 64x64 tile; larger D uses 32."""
    if D == 64:
        return 64
    if D % 32 == 0:
        return 32
    if D % 16 == 0:
        return 16
    raise ValueError(f"head dim D={D} must be 64, or divisible by 16 or 32")


def _normalize_abcd(
    learnable_abcd: Union[torch.Tensor, Sequence[float]],
    H: int,
    device: torch.device,
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    """Broadcast learnable_abcd to a contiguous [H, 4] tensor.

    Accepts a length-4 sequence / [4] tensor (shared by all heads) or [H, 4].
    """
    if torch.is_tensor(learnable_abcd):
        t = learnable_abcd.detach().to(device=device, dtype=dtype)
    else:
        t = torch.tensor(list(learnable_abcd), device=device, dtype=dtype)
    if t.numel() == 4:
        t = t.reshape(1, 4).expand(H, 4).contiguous()
    elif t.shape == (H, 4):
        t = t.contiguous()
    else:
        raise ValueError(
            f"learnable_abcd must be [4] or [H, 4] with H={H}, got {tuple(t.shape)}"
        )
    return t


@triton.autotune(
    configs=[
        triton.Config({}, num_warps=num_warps, num_stages=num_stages)
        for num_warps in [2, 4, 8]
        for num_stages in [1, 2, 3]
    ],
    key=["D", "BLOCK_D", "load_fro"],
)
@triton.jit(do_not_specialize=["T"])
def q_kkt_solve_approx_gating_forward_kernel(
    h_kk_ptr,
    k_ptr,
    q_ptr,
    gkk_ptr,
    abcd_ptr,
    x_out_ptr,
    o1_ptr,
    o2_ptr,
    o3_ptr,
    fro_ptr,
    T,
    H: tl.constexpr,
    D: tl.constexpr,
    chunk_size: tl.constexpr,
    BLOCK_D: tl.constexpr,
    load_fro: tl.constexpr,
):
    """Tiled GLA apply of phi(H) ~ a I + b H/F + c H^2/F^2 + d H^3/F^3.

    Grid: (num_chunks, B*H). D is walked in BLOCK_D tiles so D=128 stays
    [C, BD] / [BD, BD] instead of a live [D, D] plus fro intermediates.
    Stores o3 so backward does not reconstruct it via /d.
    """
    chunk_id, bh_id = tl.program_id(0), tl.program_id(1)
    b_id, h_id = bh_id // H, bh_id % H
    num_chunks = tl.cdiv(T, chunk_size)
    NUM_D: tl.constexpr = D // BLOCK_D

    scalar_off = b_id * T * H + h_id
    gkk_ptr += scalar_off
    vec_off = scalar_off * D
    q_ptr += vec_off
    x_out_ptr += vec_off
    o1_ptr += vec_off
    o2_ptr += vec_off
    o3_ptr += vec_off
    k_ptr += vec_off
    h_kk_ptr += ((b_id * num_chunks + chunk_id) * H + h_id).to(tl.int64) * D * D

    p_gkk = tl.make_block_ptr(
        gkk_ptr, (T,), (H,), (chunk_id * chunk_size,), (chunk_size,), (0,)
    )
    gkk = tl.load(p_gkk, boundary_check=(0,)).to(tl.float32)
    o_t = chunk_id * chunk_size + tl.arange(0, chunk_size)
    m_t = o_t < T
    mask = tl.where(
        (o_t[:, None] >= o_t[None, :]) & (m_t[:, None] & m_t[None, :]),
        exp(gkk[:, None] - gkk[None, :]),
        0.0,
    )
    exp_gkk = exp(gkk[:, None])

    if load_fro == 1:
        fro_ptr += scalar_off
        p_fro = tl.make_block_ptr(
            fro_ptr, (T, 1), (H, 1), (chunk_id * chunk_size, 0), (chunk_size, 1), (1, 0)
        )
        fro = tl.load(p_fro, boundary_check=(0, 1)).to(tl.float32)
    else:
        S_kk = _bwd_dot_xyT(
            k_ptr, k_ptr, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
        )
        n0 = tl.zeros((1,), dtype=tl.float32)
        vec = tl.zeros((chunk_size,), dtype=tl.float32)
        for i in tl.static_range(0, NUM_D):
            d0 = i * BLOCK_D
            kh = _fwd_vh(
                k_ptr, h_kk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D, NUM_D
            )
            ki = _bwd_load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            vec += tl.sum(kh * ki, axis=1)
            for j in tl.static_range(0, NUM_D):
                d1 = j * BLOCK_D
                h_tile = _bwd_load_mat(h_kk_ptr, D, d0, d1, BLOCK_D)
                n0 += tl.sum(tl.sum(h_tile * h_tile, axis=0), axis=0)
        intra = tl.sum(tl.dot(mask, S_kk * S_kk) * mask, axis=1, keep_dims=True)
        mixed = tl.sum(mask * vec[None, :], axis=1, keep_dims=True)
        n0_s = tl.sum(n0)
        fro = tl.sqrt(intra + exp_gkk * (exp_gkk * n0_s) + 2.0 * exp_gkk * mixed)
        fro_ptr += scalar_off
        p_fro = tl.make_block_ptr(
            fro_ptr, (T, 1), (H, 1), (chunk_id * chunk_size, 0), (chunk_size, 1), (1, 0)
        )
        tl.store(
            p_fro,
            fro.to(p_fro.dtype.element_ty, fp_downcast_rounding="rtne"),
            boundary_check=(0, 1),
        )

    fro_safe = fro + 1e-12
    S_qk = _bwd_dot_xyT(
        q_ptr, k_ptr, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
    )
    W = S_qk * mask
    for i in tl.static_range(0, NUM_D):
        d0 = i * BLOCK_D
        qh = _fwd_vh(
            q_ptr, h_kk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D, NUM_D
        )
        ki = _bwd_load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        o1 = (exp_gkk * qh + tl.dot(W, ki)) / fro_safe
        _bwd_store_vec(o1_ptr, o1, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)

    S_o1k = _bwd_dot_xyT(
        o1_ptr, k_ptr, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
    )
    W2 = S_o1k * mask
    for i in tl.static_range(0, NUM_D):
        d0 = i * BLOCK_D
        o1h = _fwd_vh(
            o1_ptr, h_kk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D, NUM_D
        )
        ki = _bwd_load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        o2 = (exp_gkk * o1h + tl.dot(W2, ki)) / fro_safe
        _bwd_store_vec(o2_ptr, o2, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)

    S_o2k = _bwd_dot_xyT(
        o2_ptr, k_ptr, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
    )
    W3 = S_o2k * mask
    a = tl.load(abcd_ptr + h_id * 4 + 0).to(tl.float32)
    b = tl.load(abcd_ptr + h_id * 4 + 1).to(tl.float32)
    c = tl.load(abcd_ptr + h_id * 4 + 2).to(tl.float32)
    d = tl.load(abcd_ptr + h_id * 4 + 3).to(tl.float32)
    for i in tl.static_range(0, NUM_D):
        d0 = i * BLOCK_D
        o2h = _fwd_vh(
            o2_ptr, h_kk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D, NUM_D
        )
        ki = _bwd_load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        o2i = _bwd_load_vec(o2_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        o1i = _bwd_load_vec(o1_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        qi = _bwd_load_vec(q_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        o3 = (exp_gkk * o2h + tl.dot(W3, ki)) / fro_safe
        _bwd_store_vec(o3_ptr, o3, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
        _bwd_store_vec(
            x_out_ptr,
            a * qi + b * o1i + c * o2i + d * o3,
            T,
            H,
            D,
            chunk_id,
            chunk_size,
            d0,
            BLOCK_D,
        )


def q_kkt_solve_approx_forward_triton(
    k: torch.Tensor,
    q: torch.Tensor,
    gkk: torch.Tensor,
    fro: torch.Tensor,
    learnable_abcd: list = [1.0, -0.5, 0.375, -0.3125],
    chunk_size: int = 64,
    load_fro: int = 0,
    output_final_state: bool = False,
    h0=None,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    Solves q phi(k^T k) where phi(x) = x^(-1/2) using chunked processing.

    Cubic polynomial: x = a q + b (q @ H)/F + c (q @ H^2)/F^2 + d (q @ H^3)/F^3.
    Also stores o3 so backward does not reconstruct it via /d.
    """
    h_kk, h_kk_final = chunk_fwd_h(
        k=k,
        v=k,
        g=gkk,
        gk=None,
        gv=None,
        h0=h0,
        output_final_state=output_final_state,
        states_in_fp32=False,
        cu_seqlens=None,
        chunk_size=chunk_size,
    )

    B, T, H, D = q.shape

    num_chunks = triton.cdiv(T, chunk_size)
    grid = (num_chunks, H * B)

    x_out = torch.empty_like(q)
    o1 = torch.empty_like(q)
    o2 = torch.empty_like(q)
    o3 = torch.empty_like(q)

    abcd_heads = _normalize_abcd(learnable_abcd, H, q.device, torch.float32)
    block_d = _choose_block_d(D)
    q_kkt_solve_approx_gating_forward_kernel[grid](
        h_kk,
        k,
        q,
        gkk,
        abcd_heads,
        x_out,
        o1,
        o2,
        o3,
        fro,
        T,
        H,
        D,
        chunk_size,
        block_d,
        load_fro,
    )

    return x_out, o1, o2, o3, fro, h_kk, h_kk_final


def q_kkt_solve_approx_backward_triton(
    k: torch.Tensor,
    dx: torch.Tensor,
    gkk: torch.Tensor,
    fro: torch.Tensor,
    learnable_abcd: list = [1.0, -0.5, 0.375, -0.3125],
    chunk_size: int = 64,
    load_fro: int = 1,
    output_final_state: bool = False,
    h0=None,
    h_kk: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    Fused backward apply of self-adjoint phi(H).

        dq  = phi(H) dx = a dx + b (dx @ H)/F + c (dx @ H^2)/F^2 + d (dx @ H^3)/F^3
        dx1 = (dx @ H) / F
        dx2 = (dx @ H^2) / F^2

    Pass ``h_kk`` from the forward to skip recomputing ``chunk_fwd_h``.
    """
    if h_kk is None:
        h_kk, h_kk_final = chunk_fwd_h(
            k=k,
            v=k,
            g=gkk,
            gk=None,
            gv=None,
            h0=h0,
            output_final_state=output_final_state,
            states_in_fp32=False,
            cu_seqlens=None,
            chunk_size=chunk_size,
        )
    else:
        h_kk_final = None

    B, T, H, D = dx.shape
    num_chunks = triton.cdiv(T, chunk_size)
    grid = (num_chunks, H * B)

    dq = torch.empty_like(dx)
    dx1 = torch.empty_like(dx)
    dx2 = torch.empty_like(dx)
    # Forward kernel now also stores o3; backward only needs dq / dx1 / dx2.
    dx3 = torch.empty_like(dx)

    abcd_heads = _normalize_abcd(learnable_abcd, H, dx.device, torch.float32)
    block_d = _choose_block_d(D)
    q_kkt_solve_approx_gating_forward_kernel[grid](
        h_kk,
        k,
        dx,
        gkk,
        abcd_heads,
        dq,
        dx1,
        dx2,
        dx3,
        fro,
        T,
        H,
        D,
        chunk_size,
        block_d,
        load_fro,
    )

    return dq, dx1, dx2, fro, h_kk, h_kk_final


@triton.jit
def _bwd_load_vec(
    ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D: tl.constexpr
):
    """Load a [chunk_size, BLOCK_D] tile as fp32.

    Storage may be bf16; promote to fp32 so G_partial / dgk accumulate
    in TF32 MMA instead of truncating operands to bf16.
    """
    p = tl.make_block_ptr(
        ptr,
        (T, D),
        (H * D, 1),
        (chunk_id * chunk_size, d0),
        (chunk_size, BLOCK_D),
        (1, 0),
    )
    x = tl.load(p, boundary_check=(0, 1)).to(tl.float32)
    return tl.where(m_t[:, None], x, 0.0)


@triton.jit
def _bwd_store_vec(ptr, val, T, H, D, chunk_id, chunk_size, d0, BLOCK_D: tl.constexpr):
    p = tl.make_block_ptr(
        ptr,
        (T, D),
        (H * D, 1),
        (chunk_id * chunk_size, d0),
        (chunk_size, BLOCK_D),
        (1, 0),
    )
    tl.store(
        p,
        val.to(p.dtype.element_ty, fp_downcast_rounding="rtne"),
        boundary_check=(0, 1),
    )


@triton.jit
def _bwd_load_mat(ptr, D, r0, c0, BLOCK_D: tl.constexpr):
    p = tl.make_block_ptr(
        ptr, (D, D), (D, 1), (r0, c0), (BLOCK_D, BLOCK_D), (1, 0)
    )
    return tl.load(p, boundary_check=(0, 1)).to(tl.float32)


@triton.jit
def _bwd_store_mat(ptr, val, D, r0, c0, BLOCK_D: tl.constexpr):
    p = tl.make_block_ptr(
        ptr, (D, D), (D, 1), (r0, c0), (BLOCK_D, BLOCK_D), (1, 0)
    )
    tl.store(p, val.to(p.dtype.element_ty), boundary_check=(0, 1))


@triton.jit
def _bwd_dot_xyT(
    x_ptr,
    y_ptr,
    T,
    H,
    D,
    chunk_id,
    chunk_size,
    m_t,
    BLOCK_D: tl.constexpr,
    NUM_D: tl.constexpr,
):
    S = tl.zeros((chunk_size, chunk_size), dtype=tl.float32)
    for i in tl.static_range(0, NUM_D):
        d0 = i * BLOCK_D
        x = _bwd_load_vec(x_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        y = _bwd_load_vec(y_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        S += tl.dot(x, tl.trans(y))
    return S


@triton.jit
def _bwd_acc_weighted(
    dk_ptr,
    v_ptr,
    A,
    S,
    T,
    H,
    D,
    chunk_id,
    chunk_size,
    m_t,
    BLOCK_D: tl.constexpr,
    NUM_D: tl.constexpr,
):
    for i in tl.static_range(0, NUM_D):
        d0 = i * BLOCK_D
        v = _bwd_load_vec(v_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        dk = _bwd_load_vec(dk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        _bwd_store_vec(
            dk_ptr,
            dk + tl.dot(tl.trans(A * S), v),
            T,
            H,
            D,
            chunk_id,
            chunk_size,
            d0,
            BLOCK_D,
        )


@triton.jit
def _bwd_h0v(
    v_ptr,
    h0_ptr,
    T,
    H,
    D,
    chunk_id,
    chunk_size,
    d0,
    m_t,
    BLOCK_D: tl.constexpr,
    NUM_D: tl.constexpr,
):
    """(v @ h0^T)[:, d0:d0+BD] = sum_d1 v[:, d1] @ h0[d0, d1].T"""
    acc = tl.zeros((chunk_size, BLOCK_D), dtype=tl.float32)
    for j in tl.static_range(0, NUM_D):
        d1 = j * BLOCK_D
        v1 = _bwd_load_vec(v_ptr, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D)
        h01 = _bwd_load_mat(h0_ptr, D, d0, d1, BLOCK_D)
        acc += tl.dot(v1, tl.trans(h01))
    return acc


@triton.jit
def _fwd_vh(
    v_ptr,
    h_ptr,
    T,
    H,
    D,
    chunk_id,
    chunk_size,
    d0,
    m_t,
    BLOCK_D: tl.constexpr,
    NUM_D: tl.constexpr,
):
    """(v @ h)[:, d0:d0+BD] = sum_d1 v[:, d1] @ h[d1, d0]."""
    acc = tl.zeros((chunk_size, BLOCK_D), dtype=tl.float32)
    for j in tl.static_range(0, NUM_D):
        d1 = j * BLOCK_D
        v1 = _bwd_load_vec(v_ptr, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D)
        h01 = _bwd_load_mat(h_ptr, D, d1, d0, BLOCK_D)
        acc += tl.dot(v1, h01)
    return acc


@triton.jit
def _bwd_gin_reverse_scan_kernel(
    g_partial_ptr,
    scale_last_ptr,
    gin_ptr,
    dht_ptr,
    NC: tl.constexpr,
    H: tl.constexpr,
    D: tl.constexpr,
    BLOCK_D: tl.constexpr,
    HAS_DHT: tl.constexpr,
):
    """gin[c] = g_partial[c+1] + scale_last[c+1] * gin[c+1], gin[-1] = dht.

    Grid: (B*H, NUM_D*NUM_D). Each program carries one [BLOCK_D, BLOCK_D]
    tile; tiles are independent (scalar * matrix). D=64 uses one tile.
    A full [128, 128] fp32 carry would exceed A100 SMEM.
    """
    i_bh = tl.program_id(0)
    i_tile = tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H
    NUM_D: tl.constexpr = D // BLOCK_D
    r0 = (i_tile // NUM_D) * BLOCK_D
    c0 = (i_tile % NUM_D) * BLOCK_D
    G = tl.zeros((BLOCK_D, BLOCK_D), dtype=tl.float32)
    if HAS_DHT:
        p_dht = tl.make_block_ptr(
            dht_ptr + (i_b * H + i_h).to(tl.int64) * D * D,
            (D, D),
            (D, 1),
            (r0, c0),
            (BLOCK_D, BLOCK_D),
            (1, 0),
        )
        G = tl.load(p_dht, boundary_check=(0, 1)).to(tl.float32)
    last = NC - 1
    p_gin = tl.make_block_ptr(
        gin_ptr + ((i_b * NC + last) * H + i_h).to(tl.int64) * D * D,
        (D, D),
        (D, 1),
        (r0, c0),
        (BLOCK_D, BLOCK_D),
        (1, 0),
    )
    tl.store(p_gin, G.to(p_gin.dtype.element_ty), boundary_check=(0, 1))
    # Triton range() does not reliably support a negative step; walk it=0..NC-2.
    for it in tl.range(0, NC - 1):
        cid = NC - 2 - it
        src = cid + 1
        p_gp = tl.make_block_ptr(
            g_partial_ptr + ((i_b * NC + src) * H + i_h).to(tl.int64) * D * D,
            (D, D),
            (D, 1),
            (r0, c0),
            (BLOCK_D, BLOCK_D),
            (1, 0),
        )
        gp = tl.load(p_gp, boundary_check=(0, 1)).to(tl.float32)
        s = tl.load(scale_last_ptr + (i_b * NC + src) * H + i_h).to(tl.float32)
        G = gp + s * G
        p_gin = tl.make_block_ptr(
            gin_ptr + ((i_b * NC + cid) * H + i_h).to(tl.int64) * D * D,
            (D, D),
            (D, 1),
            (r0, c0),
            (BLOCK_D, BLOCK_D),
            (1, 0),
        )
        tl.store(p_gin, G.to(p_gin.dtype.element_ty), boundary_check=(0, 1))



@triton.jit(do_not_specialize=["T"])
def q_kkt_bwd_chunk_kernel(
    h_kk_ptr,
    k_ptr,
    q_ptr,
    o1_ptr,
    du_ptr,
    dv_ptr,
    alpha_ptr,
    gkk_ptr,
    gin_ptr,
    g_partial_ptr,
    scale_last_ptr,
    dk_ptr,
    dgk_ptr,
    T,
    H: tl.constexpr,
    D: tl.constexpr,
    chunk_size: tl.constexpr,
    BLOCK_D: tl.constexpr,
    STAGE: tl.constexpr,
    HAS_GK: tl.constexpr,
):
    """Intra-chunk dk/dgk for the (q, o1, du, dv) terms. D is tiled by BLOCK_D.

    D=64 uses BLOCK_D=64 (one tile). D=128 uses BLOCK_D=32.
    Cubic (o2, dw) terms stay in ``q_kkt_bwd_chunk_o2_kernel`` to keep SMEM
    under A100's 163 KiB when BLOCK_D=64.

    STAGE 0: no G_in. Writes intra dk/dgk, G_partial, scale_last.
    STAGE 1: loads per-chunk G_in (after reverse scan) and adds boundary terms.

    dgk_t = <dH_t, H_t - k_t k_t^T> is formed with strictly-lower-triangular A
    (previous tokens only), avoiding the unstable <dH, H> - 0.5 <k, dk> split.
    """
    chunk_id, bh_id = tl.program_id(0), tl.program_id(1)
    b_id, h_id = bh_id // H, bh_id % H
    num_chunks = tl.cdiv(T, chunk_size)
    NUM_D: tl.constexpr = D // BLOCK_D

    scalar_off = b_id * T * H + h_id
    gkk_ptr += scalar_off
    alpha_ptr += scalar_off
    dgk_ptr += scalar_off
    vec_off = scalar_off * D
    k_ptr += vec_off
    q_ptr += vec_off
    o1_ptr += vec_off
    du_ptr += vec_off
    dv_ptr += vec_off
    dk_ptr += vec_off
    mat_off = ((b_id * num_chunks + chunk_id) * H + h_id).to(tl.int64) * D * D
    h_kk_ptr += mat_off
    gin_ptr += mat_off
    g_partial_ptr += mat_off

    p_gkk = tl.make_block_ptr(
        gkk_ptr, (T,), (H,), (chunk_id * chunk_size,), (chunk_size,), (0,)
    )
    p_dgk = tl.make_block_ptr(
        dgk_ptr, (T,), (H,), (chunk_id * chunk_size,), (chunk_size,), (0,)
    )
    gkk = tl.load(p_gkk, boundary_check=(0,)).to(tl.float32)
    o_t = chunk_id * chunk_size + tl.arange(0, chunk_size)
    m_t = o_t < T
    A = tl.where(
        (o_t[:, None] >= o_t[None, :]) & (m_t[:, None] & m_t[None, :]),
        exp(gkk[:, None] - gkk[None, :]),
        0.0,
    )
    # Strict causal: H_t - k_t k_t^T, so dgk_t = <dH_t, exp(gk_t) H_{t-1}>
    # without subtracting <dH, kk^T> (that cancellation is the dgk error source).
    A_strict = tl.where(o_t[:, None] > o_t[None, :], A, 0.0)
    scale = tl.where(m_t, exp(gkk), 0.0)
    chunk_range = tl.arange(0, chunk_size)
    last = tl.minimum(chunk_size, T - chunk_id * chunk_size) - 1
    is_last = chunk_range == last
    w_last = tl.sum(tl.where(is_last[:, None], A, 0.0), axis=0)
    scale_last = tl.sum(tl.where(is_last, scale, 0.0))

    if STAGE == 0:
        p_alpha = tl.make_block_ptr(
            alpha_ptr, (T,), (H,), (chunk_id * chunk_size,), (chunk_size,), (0,)
        )
        alpha = tl.where(m_t, tl.load(p_alpha, boundary_check=(0,)).to(tl.float32), 0.0)

        S_duk = _bwd_dot_xyT(
            du_ptr, k_ptr, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
        )
        S_qk = _bwd_dot_xyT(
            q_ptr, k_ptr, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
        )
        _bwd_acc_weighted(
            dk_ptr, q_ptr, A, S_duk, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
        )
        _bwd_acc_weighted(
            dk_ptr, du_ptr, A, S_qk, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
        )
        M = tl.dot(tl.trans(S_duk) * tl.trans(S_qk), A)

        S_dvk = _bwd_dot_xyT(
            dv_ptr, k_ptr, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
        )
        S_o1k = _bwd_dot_xyT(
            o1_ptr, k_ptr, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
        )
        _bwd_acc_weighted(
            dk_ptr, o1_ptr, A, S_dvk, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
        )
        _bwd_acc_weighted(
            dk_ptr, dv_ptr, A, S_o1k, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
        )
        M += tl.dot(tl.trans(S_dvk) * tl.trans(S_o1k), A)

        beta = tl.sum(A * (alpha * scale)[:, None], axis=0)
        z = tl.zeros((chunk_size,), dtype=tl.float32)
        n0 = tl.zeros((1,), dtype=tl.float32)
        vec_h0 = tl.zeros((chunk_size,), dtype=tl.float32)
        for i in tl.static_range(0, NUM_D):
            d0 = i * BLOCK_D
            h0k = _bwd_h0v(
                k_ptr,
                h_kk_ptr,
                T,
                H,
                D,
                chunk_id,
                chunk_size,
                d0,
                m_t,
                BLOCK_D,
                NUM_D,
            )
            k0 = _bwd_load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            dk = _bwd_load_vec(dk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            _bwd_store_vec(
                dk_ptr,
                dk + 2.0 * beta[:, None] * h0k,
                T,
                H,
                D,
                chunk_id,
                chunk_size,
                d0,
                BLOCK_D,
            )
            z += tl.sum(h0k * k0, axis=1)
            h0q = _bwd_h0v(
                q_ptr,
                h_kk_ptr,
                T,
                H,
                D,
                chunk_id,
                chunk_size,
                d0,
                m_t,
                BLOCK_D,
                NUM_D,
            )
            h0o1 = _bwd_h0v(
                o1_ptr,
                h_kk_ptr,
                T,
                H,
                D,
                chunk_id,
                chunk_size,
                d0,
                m_t,
                BLOCK_D,
                NUM_D,
            )
            du0 = _bwd_load_vec(du_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            dv0 = _bwd_load_vec(dv_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            vec_h0 += tl.sum(h0q * du0, axis=1) + tl.sum(h0o1 * dv0, axis=1)
            for j in tl.static_range(0, NUM_D):
                d1 = j * BLOCK_D
                h0_tile = _bwd_load_mat(h_kk_ptr, D, d0, d1, BLOCK_D)
                n0 += tl.sum(tl.sum(h0_tile * h0_tile, axis=0), axis=0)

        P = tl.dot(tl.trans(A), alpha[:, None] * A)
        S_kk = _bwd_dot_xyT(
            k_ptr, k_ptr, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
        )
        ones = tl.zeros((chunk_size, chunk_size), dtype=tl.float32) + 1.0
        _bwd_acc_weighted(
            dk_ptr,
            k_ptr,
            2.0 * (S_kk * P),
            ones,
            T,
            H,
            D,
            chunk_id,
            chunk_size,
            m_t,
            BLOCK_D,
            NUM_D,
        )

        c0 = tl.sum(alpha * scale * scale)
        for i in tl.static_range(0, NUM_D):
            d0 = i * BLOCK_D
            q0 = _bwd_load_vec(q_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            o10 = _bwd_load_vec(o1_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            k0 = _bwd_load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            for j in tl.static_range(0, NUM_D):
                d1 = j * BLOCK_D
                du1 = _bwd_load_vec(
                    du_ptr, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D
                )
                dv1 = _bwd_load_vec(
                    dv_ptr, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D
                )
                k1 = _bwd_load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D)
                h0_tile = _bwd_load_mat(h_kk_ptr, D, d0, d1, BLOCK_D)
                Rout = tl.dot(tl.trans(scale[:, None] * q0), du1) + tl.dot(
                    tl.trans(scale[:, None] * o10), dv1
                )
                G_partial = (
                    Rout
                    + c0 * h0_tile
                    + tl.dot(tl.trans(beta[:, None] * k0), k1)
                )
                _bwd_store_mat(g_partial_ptr, G_partial, D, d0, d1, BLOCK_D)
        tl.store(scale_last_ptr + (b_id * num_chunks + chunk_id) * H + h_id, scale_last)

        RH = scale * tl.sum(A * vec_h0[:, None], axis=0) + tl.sum(
            A_strict * tl.trans(M), axis=1
        )
        Az = tl.sum(A * z[None, :], axis=1)
        Az_prev = tl.sum(A_strict * z[None, :], axis=1)
        N = tl.dot(A, tl.dot(S_kk * S_kk, tl.trans(A_strict)))
        n0_s = tl.sum(n0)
        HH = (
            n0_s * scale * beta
            + Az_prev * beta
            + scale * tl.sum(A * (alpha * Az)[:, None], axis=0)
            + tl.sum(alpha[:, None] * A * N, axis=0)
        )
        dgk = RH + HH
        tl.store(
            p_dgk,
            tl.where(m_t, dgk, 0.0).to(p_dgk.dtype.element_ty, fp_downcast_rounding="rtne"),
            boundary_check=(0,),
        )
    else:
        dgk0 = tl.load(p_dgk, boundary_check=(0,)).to(tl.float32)
        u = tl.zeros((chunk_size,), dtype=tl.float32)
        n_gh = tl.zeros((1,), dtype=tl.float32)
        for i in tl.static_range(0, NUM_D):
            d0 = i * BLOCK_D
            acc = tl.zeros((chunk_size, BLOCK_D), dtype=tl.float32)
            gink = tl.zeros((chunk_size, BLOCK_D), dtype=tl.float32)
            k0 = _bwd_load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            for j in tl.static_range(0, NUM_D):
                d1 = j * BLOCK_D
                k1 = _bwd_load_vec(k_ptr, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D)
                G_d0d1 = _bwd_load_mat(gin_ptr, D, d0, d1, BLOCK_D)
                G_d1d0 = _bwd_load_mat(gin_ptr, D, d1, d0, BLOCK_D)
                h0_tile = _bwd_load_mat(h_kk_ptr, D, d0, d1, BLOCK_D)
                acc += tl.dot(k1, G_d1d0) + tl.dot(k1, tl.trans(G_d0d1))
                gink += tl.dot(k1, tl.trans(G_d0d1))
                n_gh += tl.sum(tl.sum(G_d0d1 * h0_tile, axis=0), axis=0)
            dk0 = _bwd_load_vec(dk_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
            dk = dk0 + w_last[:, None] * acc
            _bwd_store_vec(dk_ptr, dk, T, H, D, chunk_id, chunk_size, d0, BLOCK_D)
            u += tl.sum(gink * k0, axis=1)
        Gin_H = scale * tl.sum(n_gh) + tl.sum(A_strict * u[None, :], axis=1)
        dgk = dgk0 + w_last * Gin_H
        tl.store(
            p_dgk,
            tl.where(m_t, dgk, 0.0).to(p_dgk.dtype.element_ty, fp_downcast_rounding="rtne"),
            boundary_check=(0,),
        )


@triton.jit(do_not_specialize=["T"])
def q_kkt_bwd_chunk_o2_kernel(
    h_kk_ptr,
    k_ptr,
    o2_ptr,
    dw_ptr,
    gkk_ptr,
    g_partial_ptr,
    dk_ptr,
    dgk_ptr,
    T,
    H: tl.constexpr,
    D: tl.constexpr,
    chunk_size: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    """Add cubic (o2, dw) contributions onto STAGE-0 dk / G_partial / dgk.

    Same BLOCK_D tiling as ``q_kkt_bwd_chunk_kernel``. Kept separate so
    A100 SMEM stays under 163 KiB when D=64 / BLOCK_D=64.
    """
    chunk_id, bh_id = tl.program_id(0), tl.program_id(1)
    b_id, h_id = bh_id // H, bh_id % H
    num_chunks = tl.cdiv(T, chunk_size)
    NUM_D: tl.constexpr = D // BLOCK_D

    scalar_off = b_id * T * H + h_id
    gkk_ptr += scalar_off
    dgk_ptr += scalar_off
    vec_off = scalar_off * D
    k_ptr += vec_off
    o2_ptr += vec_off
    dw_ptr += vec_off
    dk_ptr += vec_off
    mat_off = ((b_id * num_chunks + chunk_id) * H + h_id).to(tl.int64) * D * D
    h_kk_ptr += mat_off
    g_partial_ptr += mat_off

    p_gkk = tl.make_block_ptr(
        gkk_ptr, (T,), (H,), (chunk_id * chunk_size,), (chunk_size,), (0,)
    )
    p_dgk = tl.make_block_ptr(
        dgk_ptr, (T,), (H,), (chunk_id * chunk_size,), (chunk_size,), (0,)
    )
    gkk = tl.load(p_gkk, boundary_check=(0,)).to(tl.float32)
    o_t = chunk_id * chunk_size + tl.arange(0, chunk_size)
    m_t = o_t < T
    A = tl.where(
        (o_t[:, None] >= o_t[None, :]) & (m_t[:, None] & m_t[None, :]),
        exp(gkk[:, None] - gkk[None, :]),
        0.0,
    )
    A_strict = tl.where(o_t[:, None] > o_t[None, :], A, 0.0)
    scale = tl.where(m_t, exp(gkk), 0.0)

    S_dwk = _bwd_dot_xyT(
        dw_ptr, k_ptr, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
    )
    S_o2k = _bwd_dot_xyT(
        o2_ptr, k_ptr, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
    )
    _bwd_acc_weighted(
        dk_ptr, o2_ptr, A, S_dwk, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
    )
    _bwd_acc_weighted(
        dk_ptr, dw_ptr, A, S_o2k, T, H, D, chunk_id, chunk_size, m_t, BLOCK_D, NUM_D
    )

    vec_h0 = tl.zeros((chunk_size,), dtype=tl.float32)
    for i in tl.static_range(0, NUM_D):
        d0 = i * BLOCK_D
        h0o2 = _bwd_h0v(
            o2_ptr,
            h_kk_ptr,
            T,
            H,
            D,
            chunk_id,
            chunk_size,
            d0,
            m_t,
            BLOCK_D,
            NUM_D,
        )
        dw0 = _bwd_load_vec(dw_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        vec_h0 += tl.sum(h0o2 * dw0, axis=1)

    for i in tl.static_range(0, NUM_D):
        d0 = i * BLOCK_D
        o20 = _bwd_load_vec(o2_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        for j in tl.static_range(0, NUM_D):
            d1 = j * BLOCK_D
            dw1 = _bwd_load_vec(
                dw_ptr, T, H, D, chunk_id, chunk_size, d1, m_t, BLOCK_D
            )
            Rout = tl.dot(tl.trans(scale[:, None] * o20), dw1)
            G = _bwd_load_mat(g_partial_ptr, D, d0, d1, BLOCK_D) + Rout
            _bwd_store_mat(g_partial_ptr, G, D, d0, d1, BLOCK_D)

    M = tl.dot(tl.trans(S_dwk) * tl.trans(S_o2k), A)
    RH = scale * tl.sum(A * vec_h0[:, None], axis=0) + tl.sum(
        A_strict * tl.trans(M), axis=1
    )
    dgk0 = tl.load(p_dgk, boundary_check=(0,)).to(tl.float32)
    dgk = dgk0 + RH
    tl.store(
        p_dgk,
        tl.where(m_t, dgk, 0.0).to(p_dgk.dtype.element_ty, fp_downcast_rounding="rtne"),
        boundary_check=(0,),
    )


def _bwd_dH_to_dk_dgk(
    k: torch.Tensor,
    q: torch.Tensor,
    o1: torch.Tensor,
    o2: torch.Tensor,
    du: torch.Tensor,
    dv: torch.Tensor,
    dw: torch.Tensor,
    alpha: torch.Tensor,
    gk: Optional[torch.Tensor],
    gkk: Optional[torch.Tensor],
    dht: Optional[torch.Tensor],
    h_kk: torch.Tensor,
    h0,
    chunk_size: int,
    scan_mode: str = "gpu_scan",
    block_d: Optional[int] = None,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[torch.Tensor]]:
    """
    Reverse-mode through H_t = exp(gk_t) H_{t-1} + k_t k_t^T.

    Intra-chunk work is a Triton kernel with grid (num_chunks, B*H).
    D is tiled by BLOCK_D (64 for D=64, 32 for D=128). Cubic (o2, dw) terms
    are a second kernel after STAGE 0. Inter-chunk G_in is a tiled reverse
    scan (grid (B*H, NUM_D^2)).

    scan_mode:
      python   – STAGE 0 || o2 extra || host loop over chunks || STAGE 1
      gpu_scan – STAGE 0 || o2 extra || one Triton reverse-scan kernel || STAGE 1
    """
    B, T, nH, D = k.shape
    block_d = int(block_d) if block_d is not None else _choose_block_d(D)
    if D % block_d != 0:
        raise ValueError(f"D={D} must be divisible by BLOCK_D={block_d}")
    if scan_mode not in ("python", "gpu_scan"):
        raise ValueError(f"unknown scan_mode={scan_mode!r}")
    num_chunks = (T + chunk_size - 1) // chunk_size
    k = k.contiguous()
    q = q.contiguous()
    o1 = o1.contiguous()
    o2 = o2.contiguous()
    du = du.contiguous()
    dv = dv.contiguous()
    dw = dw.contiguous()
    alpha = alpha.contiguous()
    h_kk = h_kk.contiguous()
    if gkk is None:
        gkk = torch.zeros(B, T, nH, device=k.device, dtype=torch.float32)
    has_gk = gk is not None
    dk = torch.zeros_like(k, dtype=torch.float32)
    dgk = torch.zeros(B, T, nH, device=k.device, dtype=torch.float32)
    # STAGE 0/1 have no autotune (would re-run and double-add into dk).
    # Sweep on A100: (4 warps, 1–3 stages) all ~0.39 ms; 8 warps is slower.
    launch = dict(num_warps=4, num_stages=1)

    g_partial = torch.empty(B, num_chunks, nH, D, D, device=k.device, dtype=torch.float32)
    scale_last = torch.empty(B, num_chunks, nH, device=k.device, dtype=torch.float32)
    gin = torch.empty(B, num_chunks, nH, D, D, device=k.device, dtype=torch.float32)
    grid = (num_chunks, nH * B)

    q_kkt_bwd_chunk_kernel[grid](
        h_kk,
        k,
        q,
        o1,
        du,
        dv,
        alpha,
        gkk,
        gin,
        g_partial,
        scale_last,
        dk,
        dgk,
        T,
        nH,
        D,
        chunk_size,
        block_d,
        0,
        int(has_gk),
        **launch,
    )
    q_kkt_bwd_chunk_o2_kernel[grid](
        h_kk,
        k,
        o2,
        dw,
        gkk,
        g_partial,
        dk,
        dgk,
        T,
        nH,
        D,
        chunk_size,
        block_d,
        **launch,
    )
    if scan_mode == "python":
        if dht is not None:
            gin[:, -1] = dht.float()
        else:
            gin[:, -1] = 0
        for cid in range(num_chunks - 2, -1, -1):
            gin[:, cid] = g_partial[:, cid + 1] + scale_last[
                :, cid + 1, :, None, None
            ] * gin[:, cid + 1]
    else:
        dummy = h_kk.new_empty(B, nH, D, D)
        dht_buf = dht.float().contiguous() if dht is not None else dummy
        num_d = D // block_d
        _bwd_gin_reverse_scan_kernel[(nH * B, num_d * num_d)](
            g_partial,
            scale_last,
            gin,
            dht_buf,
            num_chunks,
            nH,
            D,
            block_d,
            int(dht is not None),
            num_warps=4,
            num_stages=1,
        )
    q_kkt_bwd_chunk_kernel[grid](
        h_kk,
        k,
        q,
        o1,
        du,
        dv,
        alpha,
        gkk,
        gin,
        g_partial,
        scale_last,
        dk,
        dgk,
        T,
        nH,
        D,
        chunk_size,
        block_d,
        1,
        int(has_gk),
        **launch,
    )
    dh0 = None
    if h0 is not None:
        dh0 = (
            g_partial[:, 0] + scale_last[:, 0, :, None, None] * gin[:, 0]
        ).to(h0.dtype)
    return (
        dk.to(k.dtype),
        dgk.to(gk.dtype) if has_gk else None,
        dh0,
    )


@triton.jit(do_not_specialize=["T"])
def q_kkt_bwd_prep_kernel(
    q_ptr,
    o1_ptr,
    o2_ptr,
    o3_ptr,
    dx_ptr,
    dx1_ptr,
    dx2_ptr,
    fro_ptr,
    abcd_ptr,
    du_ptr,
    dv_ptr,
    dw_ptr,
    alpha_ptr,
    dabcd_ptr,
    T,
    H: tl.constexpr,
    D: tl.constexpr,
    chunk_size: tl.constexpr,
    BLOCK_D: tl.constexpr,
    NEED_DABCD: tl.constexpr,
    EPS: tl.constexpr,
):
    """Fuse stored o3 / du / dv / dw / alpha / partial dabcd for one (chunk, B*H)."""
    chunk_id, bh_id = tl.program_id(0), tl.program_id(1)
    b_id, h_id = bh_id // H, bh_id % H
    NUM_D: tl.constexpr = D // BLOCK_D
    num_chunks = tl.cdiv(T, chunk_size)

    scalar_off = b_id * T * H + h_id
    fro_ptr += scalar_off
    alpha_ptr += scalar_off
    vec_off = scalar_off * D
    q_ptr += vec_off
    o1_ptr += vec_off
    o2_ptr += vec_off
    o3_ptr += vec_off
    dx_ptr += vec_off
    dx1_ptr += vec_off
    dx2_ptr += vec_off
    du_ptr += vec_off
    dv_ptr += vec_off
    dw_ptr += vec_off

    o_t = chunk_id * chunk_size + tl.arange(0, chunk_size)
    m_t = o_t < T
    p_fro = tl.make_block_ptr(
        fro_ptr, (T,), (H,), (chunk_id * chunk_size,), (chunk_size,), (0,)
    )
    fro = tl.where(m_t, tl.load(p_fro, boundary_check=(0,)).to(tl.float32), 0.0)
    F = fro + EPS
    b = tl.load(abcd_ptr + h_id * 4 + 1).to(tl.float32)
    c = tl.load(abcd_ptr + h_id * 4 + 2).to(tl.float32)
    d = tl.load(abcd_ptr + h_id * 4 + 3).to(tl.float32)

    s_o1dx = tl.zeros((chunk_size,), dtype=tl.float32)
    s_o2dx = tl.zeros((chunk_size,), dtype=tl.float32)
    s_o3dx = tl.zeros((chunk_size,), dtype=tl.float32)
    da = tl.zeros((1,), dtype=tl.float32)
    db = tl.zeros((1,), dtype=tl.float32)
    dc = tl.zeros((1,), dtype=tl.float32)
    dd = tl.zeros((1,), dtype=tl.float32)
    for i in tl.static_range(0, NUM_D):
        d0 = i * BLOCK_D
        q = _bwd_load_vec(q_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        o1 = _bwd_load_vec(o1_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        o2 = _bwd_load_vec(o2_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        o3 = _bwd_load_vec(o3_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        dx = _bwd_load_vec(dx_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        dx1 = _bwd_load_vec(dx1_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        dx2 = _bwd_load_vec(dx2_ptr, T, H, D, chunk_id, chunk_size, d0, m_t, BLOCK_D)
        _bwd_store_vec(
            du_ptr,
            (b * dx + c * dx1 + d * dx2) / F[:, None],
            T,
            H,
            D,
            chunk_id,
            chunk_size,
            d0,
            BLOCK_D,
        )
        _bwd_store_vec(
            dv_ptr,
            (c * dx + d * dx1) / F[:, None],
            T,
            H,
            D,
            chunk_id,
            chunk_size,
            d0,
            BLOCK_D,
        )
        _bwd_store_vec(
            dw_ptr, (d * dx) / F[:, None], T, H, D, chunk_id, chunk_size, d0, BLOCK_D
        )
        s_o1dx += tl.sum(o1 * dx, axis=1)
        s_o2dx += tl.sum(o2 * dx, axis=1)
        s_o3dx += tl.sum(o3 * dx, axis=1)
        if NEED_DABCD:
            da += tl.sum(tl.sum(dx * q, axis=0), axis=0)
            db += tl.sum(tl.sum(dx * o1, axis=0), axis=0)
            dc += tl.sum(tl.sum(dx * o2, axis=0), axis=0)
            dd += tl.sum(tl.sum(dx * o3, axis=0), axis=0)

    alpha = -(b * s_o1dx + 2.0 * c * s_o2dx + 3.0 * d * s_o3dx) / (F * F)
    p_alpha = tl.make_block_ptr(
        alpha_ptr, (T,), (H,), (chunk_id * chunk_size,), (chunk_size,), (0,)
    )
    tl.store(
        p_alpha,
        tl.where(m_t, alpha, 0.0).to(p_alpha.dtype.element_ty, fp_downcast_rounding="rtne"),
        boundary_check=(0,),
    )
    if NEED_DABCD:
        off = ((b_id * num_chunks + chunk_id) * H + h_id) * 4
        tl.store(dabcd_ptr + off + 0, tl.sum(da))
        tl.store(dabcd_ptr + off + 1, tl.sum(db))
        tl.store(dabcd_ptr + off + 2, tl.sum(dc))
        tl.store(dabcd_ptr + off + 3, tl.sum(dd))


def _bwd_prep_du_dv_dw_alpha(
    q: torch.Tensor,
    o1: torch.Tensor,
    o2: torch.Tensor,
    o3: torch.Tensor,
    dx: torch.Tensor,
    dx1: torch.Tensor,
    dx2: torch.Tensor,
    fro: torch.Tensor,
    abcd_heads: torch.Tensor,
    chunk_size: int,
    need_dabcd: bool,
) -> Tuple[
    torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, Optional[torch.Tensor]
]:
    B, T, H, D = q.shape
    block_d = _choose_block_d(D)
    num_chunks = (T + chunk_size - 1) // chunk_size
    du = torch.empty_like(q)
    dv = torch.empty_like(q)
    dw = torch.empty_like(q)
    alpha = torch.empty(B, T, H, device=q.device, dtype=torch.float32)
    dabcd = (
        torch.empty(B, num_chunks, H, 4, device=q.device, dtype=torch.float32)
        if need_dabcd
        else q.new_empty(1)
    )
    q_kkt_bwd_prep_kernel[(num_chunks, H * B)](
        q,
        o1,
        o2,
        o3,
        dx,
        dx1,
        dx2,
        fro,
        abcd_heads,
        du,
        dv,
        dw,
        alpha,
        dabcd,
        T,
        H,
        D,
        chunk_size,
        block_d,
        int(need_dabcd),
        1e-12,
        num_warps=4,
        num_stages=1,
    )
    d_abcd_h = dabcd.sum(dim=(0, 1)) if need_dabcd else None
    return du, dv, dw, alpha, d_abcd_h


class q_kkt_solve_approx(torch.autograd.Function):
    """
    Autograd for x_t = q_t @ phi(H_t), phi(H) ~ a I + b H/F + c H^2/F^2 + d H^3/F^3.

    a, b, c, d are per-head learnable scalars packed as a tensor of shape [H, 4].
    A length-4 / [4] input is broadcast to all heads; its gradient is summed over heads.
    """

    @staticmethod
    def forward(
        ctx,
        k: torch.Tensor,
        q: torch.Tensor,
        gk: Optional[torch.Tensor] = None,
        chunk_size: int = 64,
        learnable_abcd: Union[torch.Tensor, Sequence[float]] = (
            1.0,
            -0.5,
            0.375,
            -0.3125,
        ),
        h0=None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        B, T, H, D = q.shape
        fro = torch.empty((B, T, H), dtype=torch.float32, device=q.device)
        abc_is_tensor = torch.is_tensor(learnable_abcd)
        if abc_is_tensor:
            ctx.abc_dtype = learnable_abcd.dtype
            assert learnable_abcd.dtype == torch.float32, f"learnable_abcd.dtype must be float32, got {learnable_abcd.dtype}"
            ctx.abc_device = learnable_abcd.device
            ctx.abc_shape = tuple(learnable_abcd.shape)
        else:
            assert abc_is_tensor, "learnable_abcd must be a tensor"

        abcd_heads = _normalize_abcd(learnable_abcd, H, q.device, torch.float32)
        gkk = chunk_local_cumsum(gk, chunk_size=chunk_size) if gk is not None else None
        x_out, o1, o2, o3, fro, h_kk, h_kk_final = q_kkt_solve_approx_forward_triton(
            k,
            q,
            gkk,
            fro,
            learnable_abcd=abcd_heads,
            chunk_size=chunk_size,
            load_fro=0,
            output_final_state=True,
            h0=h0,
        )
        to_save = [k, q, o1, o2, o3, fro, abcd_heads, h_kk]
        if gk is not None:
            to_save.append(gk)
        if gkk is not None:
            to_save.append(gkk)
        if h0 is not None:
            to_save.append(h0)
        ctx.save_for_backward(*to_save)
        ctx.chunk_size = chunk_size
        ctx.has_gk = gk is not None
        ctx.has_gkk = gkk is not None
        ctx.has_h0 = h0 is not None
        return x_out, h_kk_final

    @staticmethod
    def backward(
        ctx, dx_out: torch.Tensor, d_kk_final: Optional[torch.Tensor] = None
    ) -> Tuple[
        Optional[torch.Tensor],
        Optional[torch.Tensor],
        Optional[torch.Tensor],
        None,
        Optional[torch.Tensor],
        Optional[torch.Tensor],
    ]:
        saved = list(ctx.saved_tensors)
        k, q, o1, o2, o3, fro, abcd_heads, h_kk = saved[:8]
        idx = 8
        gk = saved[idx] if ctx.has_gk else None
        idx += int(ctx.has_gk)
        gkk = saved[idx] if ctx.has_gkk else None
        idx += int(ctx.has_gkk)
        h0 = saved[idx] if ctx.has_h0 else None
        chunk_size = ctx.chunk_size

        dq, dx1, dx2, fro, h_kk, _ = q_kkt_solve_approx_backward_triton(
            k,
            dx_out,
            gkk,
            fro,
            learnable_abcd=abcd_heads,
            chunk_size=chunk_size,
            load_fro=1,
            output_final_state=False,
            h0=h0,
            h_kk=h_kk,
        )
        need_dabcd = bool(ctx.needs_input_grad[4])
        du, dv, dw, alpha, d_abcd_h = _bwd_prep_du_dv_dw_alpha(
            q,
            o1,
            o2,
            o3,
            dx_out,
            dx1,
            dx2,
            fro,
            abcd_heads,
            chunk_size,
            need_dabcd,
        )
        dk, dgk, dh0 = _bwd_dH_to_dk_dgk(
            k,
            q,
            o1,
            o2,
            du,
            dv,
            dw,
            alpha,
            gk,
            gkk,
            d_kk_final,
            h_kk,
            h0,
            chunk_size,
        )
        d_abcd = None
        if need_dabcd:
            if ctx.abc_shape == (4,) or (
                len(ctx.abc_shape) == 1 and ctx.abc_shape[0] == 4
            ):
                d_abcd = d_abcd_h.sum(dim=0)
            else:
                d_abcd = d_abcd_h
            d_abcd = d_abcd.to(dtype=ctx.abc_dtype, device=ctx.abc_device).reshape(
                ctx.abc_shape
            )
        return dk, dq, dgk, None, d_abcd, dh0


#############
def test_q_kkt_solve_approx(q, k, gk, a=1.0, b=-0.5, c=0.375, d=-0.3125):
    """
    PyTorch reference for the q-phi(KKT) approximation, where phi(x) = x^(-1/2).

    We follow the GLA recurrence to build the per-step key-key state
    H_t = g_t * H_{t-1} + k_t k_t^T, then approximate the (-1/2)-power action
    on q_t by a cubic polynomial in H_t / ||H_t||_F:

        q_t_out = a * q_t
                  + b * (q_t @ H_t) / ||H_t||_F
                  + c * (q_t @ H_t @ H_t) / ||H_t||_F^2
                  + d * (q_t @ H_t @ H_t @ H_t) / ||H_t||_F^3

    Args:
        q: Query tensor with shape [B, T, H, D].
        k: Key tensor with shape [B, T, H, D].
        gk: Raw log-gate tensor with shape [B, T, H]. Will be exp'd in use.
        a, b, c, d: Polynomial coefficients. Each may be a scalar or a length-H tensor.

    Returns:
        o: Output tensor with shape [B, T, H, D].
        states: List of length T, each [B, H, D, D] (the per-step H_t).
        fros: List of length T, each [B, H] (per-step Frobenius norm).
    """
    B, T, H, D = q.shape

    def _coeff(x):
        if torch.is_tensor(x):
            t = x.reshape(-1)
            if t.numel() == 1:
                t = t.expand(H)
            elif t.numel() != H:
                raise ValueError(f"coefficient numel must be 1 or H={H}, got {t.numel()}")
            return t.to(device=q.device).view(1, H, 1)
        return x

    a = _coeff(a)
    b = _coeff(b)
    c = _coeff(c)
    d = _coeff(d)
    state = torch.zeros(B, H, D, D, dtype=torch.float32, device=q.device)
    gkk = torch.exp(gk.float()).float()

    outs = []
    states = []
    fros = []

    for i in range(T):
        ki = k[:, i, :, :].float()  # [B, H, D]
        # GLA-style state update: H_t = exp(g_t) * H_{t-1} + k_t k_t^T
        state = gkk[:, i, :].view(B, H, 1, 1).float() * state + ki.unsqueeze(-1).float() * ki.unsqueeze(-2).float()
        F = torch.norm(state, p='fro', dim=(-2, -1), keepdim=True).squeeze(-1).float()
        F_safe = F + 1e-12
        qi = q[:, i, :, :].float()  # [B, H, D]
        q_state = (qi.unsqueeze(-2) @ state).squeeze(-2).float()
        q_state2 = (q_state.unsqueeze(-2) @ state).squeeze(-2).float()
        q_state3 = (q_state2.unsqueeze(-2) @ state).squeeze(-2).float()
        out = (
            a * qi
            + b * q_state / F_safe
            + c * q_state2 / (F_safe * F_safe)
            + d * q_state3 / (F_safe * F_safe * F_safe)
        ).to(q.dtype)
        outs.append(out)
        states.append(state.clone())
        fros.append(F.squeeze(-1).clone())
    o = torch.stack(outs, dim=1)
    return o, states, fros


##############
if __name__ == "__main__":
    k = torch.randn(1, 10, 1, 64)
    q = torch.randn(1, 10, 1, 64)
    gk = torch.randn(1, 10, 1)
    a, b, c, d = 1.0, -0.5, 0.375, -0.3125  # Taylor (1+x)^(-1/2) through x^3

    o_ref, states, fros = test_q_kkt_solve_approx(q, k, gk, a, b, c, d)
    print("Reference output shape:", o_ref.shape)
    print("Reference output:", o_ref)
    print("Number of states:", len(states), "last state shape:", states[-1].shape)
    print("Last Frobenius norm:", fros[-1])
 
 

